local json = require("json")
local Keys = {}
local windowSize = {
    640,
    460
}
local grid = {}
local timer = 0
local Settings = {
    PixelsX = 100,
    PixelsY = 50,
    GameSpeed = 1,
    LightTransparency = 0.2,
    FlameStrength = 0.2,
    HeatVision = false,
    SaveId = 1
}
function FindInTable(arr, find)
    local found
    for i, obj in pairs(arr) do
        if obj == find then
            found = i
        end
    end
    return found
end
local mouseX, mouseY
function GetDistance(x1, y1, x2, y2)
    return math.sqrt((x2 - x1) ^ 2 + (y2 - y1) ^ 2)
end
function lerp(a, b, alpha)
    return a * (1 - alpha) + b * alpha
end
function Clamp(a, min, max)
    return math.min(max, math.max(min, a))
end
function GetIfExists(x, y)
    if grid[x] ~= nil and grid[x][y] ~= nil then
        return true
    else
        return false
    end
end
function GetMaterial(x, y)
    if not GetIfExists(x, y) then
        return false
    end
    return grid[x][y]["Name"]
end
function HasTag(x, y, tag)
    if not GetIfExists(x, y) then
        return false
    end
    if FindInTable(grid[x][y]["Tags"], tag) then
        return true
    end
    return false
end
local createCopy
createCopy = function(arr)
    local copy = {}
    for i, obj in pairs(arr) do
        if type(obj) == "table" then
            copy[i] = createCopy(obj)
        else
            copy[i] = obj
        end
    end
    return copy
end
local Materials = {}
function MoveFromGrid(x, y, newx, newy)
    grid[newx][newy] = grid[x][y]
    grid[x][y] = createCopy(Materials["Air"])
end
function SetFromCopy(x, y, copy)
    grid[x][y] = copy
end
function SwapFromGrid(x, y, x1, y1)
    local copy = createCopy(grid[x][y])
    MoveFromGrid(x1, y1, x, y)
    SetFromCopy(x1, y1, copy)
end
function getRand(min, max)
    return love.math.random(max - min + 1) + min - 1
end
local ColorModes = {
    VeryRandom = function(r, g, b)
        r = Clamp(r + getRand(- 9, 9), 0, 255)
        g = Clamp(g + getRand(- 9, 9), 0, 255)
        b = Clamp(b + getRand(- 9, 9), 0, 255)
        return r, g, b
    end,
    MonoVeryRandom = function(r, g, b)
        local mod = getRand(- 9, 9)
        r = Clamp(r + mod, 0, 255)
        g = Clamp(g + mod, 0, 255)
        b = Clamp(b + mod, 0, 255)
        return r, g, b
    end,
    Randomize = function(r, g, b)
        r = Clamp(r + getRand(- 5, 5), 0, 255)
        g = Clamp(g + getRand(- 5, 5), 0, 255)
        b = Clamp(b + getRand(- 5, 5), 0, 255)
        return r, g, b
    end,
    MonoRandomize = function(r, g, b)
        local mod = getRand(- 5, 5)
        r = Clamp(r + mod, 0, 255)
        g = Clamp(g + mod, 0, 255)
        b = Clamp(b + mod, 0, 255)
        return r, g, b
    end,
    SlightRandom = function(r, g, b)
        r = Clamp(r + getRand(- 2, 2), 0, 255)
        g = Clamp(g + getRand(- 2, 2), 0, 255)
        b = Clamp(b + getRand(- 2, 2), 0, 255)
        return r, g, b
    end,
    VeryLittleRandom = function(r, g, b)
        r = Clamp(r + getRand(- 1, 1) / 1.5, 0, 255)
        g = Clamp(g + getRand(- 1, 1) / 1.5, 0, 255)
        b = Clamp(b + getRand(- 1, 1) / 1.5, 0, 255)
        return r, g, b
    end,
    None = function(r, g, b)
        return r, g, b
    end,
    Slated = function(r, g, b, x, y)
        local val = Clamp(math.abs(love.math.noise(math.floor(x / 11 * 100) / 100 + y / 2)), 0, 1)
        return lerp(r, 200, val), lerp(g, 200, val), lerp(b, 200, val)
    end
}
function GetNetwork()
end
RenderOptions = {
    Air = {
        AfterColor = ColorModes["None"],
        ColorFunc = function(x, y, r, g, b)
            return r, g, b
        end
    },
    Sand = {
        AfterColor = ColorModes["Randomize"],
        ColorFunc = function(x, y, r, g, b)
            return r, g, b
        end
    },
    Glass = {
        AfterColor = ColorModes["VeryLittleRandom"],
        ColorFunc = function(x, y, r, g, b)
            if (x % 90) - 4 < (y + math.floor(timer * 20)) % 90 and (x % 90) + 4 > (y + math.floor(timer * 20)) % 90 then
                return 255, 255, 255,.7
            else
                return r, g, b,.3
            end
        end
    },
    Well = {
        AfterColor = ColorModes["Randomize"],
        ColorFunc = function(x, y, r, g, b)
            return r, g, b
        end
    },
    Oil_Rig = {
        AfterColor = ColorModes["Randomize"],
        ColorFunc = function(x, y, r, g, b)
            return r, g, b
        end
    },
    Metal = {
        AfterColor = ColorModes["SlightRandom"],
        ColorFunc = function(x, y, r, g, b)
            local temp = grid[x][y]["Attributes"]["Temperature"]
            local val = Clamp(temp / 1000, 0, 1) ^ 2
            grid[x][y]["Attributes"]["Light"] = math.floor(lerp(0, 6, val))
            return lerp(r, 255, val), lerp(g, 160, val), lerp(b, 0, val)
        end
    },
    Stone = {
        AfterColor = ColorModes["Slated"],
        ColorFunc = function(x, y, r, g, b)
            return r, g, b
        end
    },
    Ceramic = {
        AfterColor = ColorModes["Slated"],
        ColorFunc = function(x, y, r, g, b)
            return r, g, b
        end
    },
    Flame = {
        AfterColor = ColorModes["Randomize"],
        ColorFunc = function(x, y, r, g, b)
            local temp = grid[x][y]["Attributes"]["Lifetime"]
            local val = Clamp(1 - temp / 15, 0, 1)
            return lerp(0, 255, val), lerp(89, 200, val), lerp(255, 0, val),0
        end
    },
    Frost = {
        AfterColor = ColorModes["Randomize"],
        ColorFunc = function(x, y, r, g, b)
            local temp = grid[x][y]["Attributes"]["Lifetime"]
            local val = Clamp(1 - temp / 60, 0, 1)
            return lerp(r, 255, val), lerp(g, 255, val), lerp(b, 255, val),0
        end
    },
    Wood = {
        AfterColor = ColorModes["Randomize"],
        ColorFunc = function(x, y, r, g, b)
            return r, g, b
        end
    },
    Water = {
        AfterColor = ColorModes["Randomize"],
        ColorFunc = function(x, y, r, g, b)
            return r, g, b,.5
        end
    },
    Ice = {
        AfterColor = ColorModes["SlightRandom"],
        ColorFunc = function(x, y, r, g, b)
            return r, g, b,.7
        end
    },
    Steam = {
        AfterColor = ColorModes["None"],
        ColorFunc = function(x, y, r, g, b)
            return r, g, b,.3
        end
    },
    Torch = {
        AfterColor = ColorModes["None"],
        ColorFunc = function(x, y, r, g, b)
            return r, g, b
        end
    },
    Vent = {
        AfterColor = ColorModes["None"],
        ColorFunc = function(x, y, r, g, b)
            return r, g, b
        end
    },
    Fuse = {
        AfterColor = ColorModes["SlightRandom"],
        ColorFunc = function(x, y, r, g, b)
            return r, g, b
        end
    },
    Oil = {
        AfterColor = ColorModes["VeryLittleRandom"],
        ColorFunc = function(x, y, r, g, b)
            local r = lerp(r, r + love.math.noise(x / 23, y / 79) * 15, .3)
            local g = lerp(g, g + love.math.noise(x / 94, y / 34) * 15, .3)
            local b = lerp(b, b + love.math.noise(x / 44, y / 57) * 15, .3)
            return r, g, b
        end
    },
    Seed = {
        AfterColor = ColorModes["VeryLittleRandom"],
        ColorFunc = function(x, y, r, g, b)
            if FindInTable(grid[x][y]["Tags"], "Burnt") then
                return lerp(r, 0, .8), lerp(g, 0, .8), lerp(b, 0, .8)
            end
            return r, g, b
        end
    },
    Paper = {
        AfterColor = ColorModes["MonoRandomize"],
        ColorFunc = function(x, y, r, g, b)
            return r, g, b
        end
    },
    RFan = {
        AfterColor = ColorModes["VeryLittleRandom"],
        ColorFunc = function(x, y, r, g, b)
            return r, g, b
        end
    },
    LFan = {
        AfterColor = ColorModes["VeryLittleRandom"],
        ColorFunc = function(x, y, r, g, b)
            return r, g, b
        end
    },
    Refinery = {
        AfterColor = ColorModes["VeryLittleRandom"],
        ColorFunc = function(x, y, r, g, b)
            return r, g, b
        end
    },
    Diesel = {
        AfterColor = ColorModes["VeryRandom"],
        ColorFunc = function(x, y, r, g, b)
            return r, g, b
        end
    },
    Bomb = {
        AfterColor = ColorModes["MonoVeryRandom"],
        ColorFunc = function(x, y, r, g, b)
            return r, g, b
        end
    },
    Extinguisher = {
        AfterColor = ColorModes["Randomize"],
        ColorFunc = function(x, y, r, g, b)
            return r, g, b
        end
    },
    Clay = {
        AfterColor = ColorModes["Randomize"],
        ColorFunc = function(x, y, r, g, b)
            return r, g, b
        end
    }
}
Materials = {
    Air = {
        Name = "Air",
        Color = {
            0,
            0,
            0

        },
        Attributes = {
                         },
        Tags = {
            "Airlike"
        }
    },
    Sand = {
        Name = "Sand",
        Color = {
            255,
            210,
            155
        },
        Attributes = {
            Temperature = 20,
            HeatTransfer = 0.025
        },
        Tags = {
            "Powder"
        }
    },
    Glass = {
        Name = "Glass",
        Color = {
            233,
            245,
            255
        },
        Attributes = {
            Temperature = 20,
            HeatTransfer = 0.0125
        },
        Tags = {
            "Solid"
        }
    },
    Well = {
        Name = "Well",
        Color = {
            143,
            62,
            0
        },
        Attributes = {
            Temperature = 20,
            HeatTransfer = 0.0125
        },
        Tags = {
            "Solid"
        }
    },
    Oil_Rig = {
        Name = "Oil_Rig",
        Color = {
            45,
            49,
            66
        },
        Attributes = {
            Temperature = 20,
            HeatTransfer = 0.0125
        },
        Tags = {
            "Solid"
        }
    },
    Metal = {
        Name = "Metal",
        Color = {
            110,
            110,
            110
        },
        Attributes = {
            Temperature = 20,
            HeatTransfer = .25,
            Light = 0
        },
        Tags = {
            "Solid",
            "ExplodeProof"
        }
    },
    Stone = {
        Name = "Stone",
        Color = {
            170,
            170,
            170
        },
        Attributes = {
            Temperature = 20,
            HeatTransfer = .025,
        },
        Tags = {
            "Solid",
            "ExplodeProof"
        }
    },
    Ceramic = {
        Name = "Stone",
        Color = {
            163,
            72,
            35
        },
        Attributes = {
            Temperature = 20,
            HeatTransfer = 0,
        },
        Tags = {
            "Solid",
            "ExplodeProof"
        }
    },
    Extinguisher = {
        Name = "Extinguisher",
        Color = {
            150,
            83,
            255
        },
        Attributes = {
            Temperature = 20,
            HeatTransfer = 0,
        },
        Tags = {
            "Solid",
            "Flame_Stopper"
        }
    },
    Flame = {
        Name = "Flame",
        Color = {
            255,
            200,
            0
        },
        Attributes = {
            Lifetime = 20,
            Light = 4,
            Slowed = false
        },
        Tags = {
            "Airlike"
        }
    },
    Frost = {
        Name = "Frost",
        Color = {
            25,
            75,
            255
        },
        Attributes = {
            Lifetime = 60,
            Light = 2
        },
        Tags = {
            "Airlike"
        }
    },
    Water = {
        Name = "Water",
        Color = {
            38,
            110,
            241
        },
        Attributes = {
            Temperature = 20,
            HeatTransfer = 0.05
        },
        Tags = {
            "Liquid"
        }
    },
    Ice = {
        Name = "Ice",
        Color = {
            230,
            240,
            255
        },
        Attributes = {
            Temperature = - 1,
            HeatTransfer = 0.0025
        },
        Tags = {
            "Powder"
        }
    },
    Wood = {
        Name = "Wood",
        Color = {
            143,
            69,
            20
        },
        Attributes = {
            Temperature = 20,
            HeatTransfer = 0.05,
            Lifetime = 500,
            heated = false
        },
        Tags = {
            "Heatable",
            "Powder"
        }
    },
    Fuse = {
        Name = "Fuse",
        Color = {
            255,
            250,
            215
        },
        Attributes = {
            Temperature = 20,
            HeatTransfer = 0.0001,
            Lifetime = 50,
            heated = false
        },
        Tags = {
            "Heatable",
            "Solid"
        }
    },
    Bomb = {
        Name = "Bomb",
        Color = {
            0,
            0,
            0
        },
        Attributes = {
            Temperature = 20,
            HeatTransfer = 0.0001,
            heated = false
        },
        Tags = {
            "Heatable",
            "Solid"
        }
    },
    Steam = {
        Name = "Steam",
        Color = {
            239,
            239,
            255
        },
        Attributes = {
            Temperature = 100,
            HeatTransfer = 0.0001
        },
        Tags = {
            "Gas"
        }
    },
    Torch = {
        Name = "Torch",
        Color = {
            255,
            186,
            0
        },
        Attributes = {
            Temperature = 50,
            HeatTransfer = 0.25
        },
        Tags = {
            "Solid",
            "Lit"
        }
    },
    Vent = {
        Name = "Vent",
        Color = {
            105,
            115,
            150
        },
        Attributes = {
            Temperature = - 10,
            HeatTransfer = 0.25
        },
        Tags = {
            "Solid",
            "Active"
        }
    },
    Oil = {
        Name = "Oil",
        Color = {
            33,
            21,
            21
        },
        Attributes = {
            Temperature = 20,
            HeatTransfer = .01,
            Lifetime = 1000,
            heated = false
        },
        Tags = {
            "Heatable",
            "Liquid",
        }
    },
    Paper = {
        Name = "Paper",
        Color = {
            219,
            219,
            219
        },
        Attributes = {
            Temperature = 20,
            HeatTransfer = .01,
            Lifetime = 5,
            heated = false
        },
        Tags = {
            "Heatable",
            "Solid",
            "Water_Replacable"
        }
    },
    Diesel = {
        Name = "Diesel",
        Color = {
            168,
            157,
            79
        },
        Attributes = {
            Temperature = 20,
            HeatTransfer = .01,
            Lifetime = 3000,
            heated = false
        },
        Tags = {
            "Heatable",
            "Liquid",
        }
    },
    Refinery = {
        Name = "Refinery",
        Color = {
            194,
            188,
            150
        },
        Attributes = {
            Temperature = 20,
            HeatTransfer = .01
        },
        Tags = {
            "Solid",
        }
    },
    Seed = {
        Name = "Seed",
        Color = {
            33,
            151,
            21
        },
        Attributes = {
            Temperature = 20,
            HeatTransfer = .01,
            Water = 0
        },
        Tags = {
            "Solid"
        }
    },
    Clay = {
        Name = "Clay",
        Color = {
            179,
            217,
            214
        },
        Attributes = {
            Temperature = 200,
            HeatTransfer = .01,
        },
        Tags = {}
    },
    RFan = {
        Name = "RFan",
        Color = {
            149,
            149,
            181
        },
        Attributes = {
            Temperature = 20,
            HeatTransfer = .01,
        },
        Tags = {
            "Solid"
        }
    },
    LFan = {
        Name = "LFan",
        Color = {
            149,
            149,
            181
        },
        Attributes = {
            Temperature = 20,
            HeatTransfer = .01,
        },
        Tags = {
            "Solid"
        }
    },
}
function SetGrid(x, y, material, attributes)
    if not GetIfExists(x, y) then
        return
    end
    if not Materials[material] then
        return
    end
    local copy = createCopy(Materials[material])
    for i, attr in pairs(attributes) do
        copy["Attributes"][i] = attr
    end
    local r, g, b = RenderOptions[material]["AfterColor"](copy["Color"][1], copy["Color"][2], copy["Color"][3], x, y)
    copy["Color"] = {
        r,
        g,
        b
    }
    grid[x][y] = copy
end
Ruleset = {
    Sand = function(x, y)
        if grid[x][y]["Attributes"]["Temperature"] > 300 then
            SetGrid(x, y, "Glass", {
                Temperature = 300
            })
            return
        elseif grid[x][y]["Attributes"]["Temperature"] > 200 then
            for x1 = - 1, 1, 1 do
                for y1 = - 1, 1, 1 do
                    if GetIfExists(x + x1, y + y1) and GetMaterial(x + x1, y + y1) == "Water" then
                        SetGrid(x + x1, y + y1, "Clay", {})
                        SetGrid(x, y, "Clay", {})
                        return
                    end
                end
            end
        end
        if GetIfExists(x, y - 1) and HasTag(x, y - 1, "Airlike") then
            MoveFromGrid(x, y, x, y - 1)
        elseif GetIfExists(x, y - 1) and (HasTag(x, y - 1, "Liquid") or HasTag(x, y - 1, "Gas")) then
            SwapFromGrid(x, y, x, y - 1)
        elseif GetIfExists(x - 1, y - 1) and HasTag(x - 1, y - 1, "Airlike") and HasTag(x - 1, y, "Airlike") then
            MoveFromGrid(x, y, x - 1, y - 1)
        elseif GetIfExists(x + 1, y - 1) and HasTag(x + 1, y - 1, "Airlike") and HasTag(x + 1, y, "Airlike") then
            MoveFromGrid(x, y, x + 1, y - 1)
        elseif GetIfExists(x + 1, y) and HasTag(x - 1, y, "Airlike") and GetMaterial(x, y - 1) == "Ice" then
            MoveFromGrid(x, y, x + 1, y)
        elseif GetIfExists(x - 1, y) and HasTag(x + 1, y, "Airlike") and GetMaterial(x, y - 1) == "Ice" then
            MoveFromGrid(x, y, x - 1, y)
        end
    end,
    Water = function(x, y)
        if grid[x][y]["Attributes"]["Temperature"] > 100 and getRand(1, 500) == 1 then
            SetGrid(x, y, "Steam", {
                Temperature = grid[x][y]["Attributes"]["Temperature"]
            })
            return
        end
        if grid[x][y]["Attributes"]["Temperature"] <= 0 then
            SetGrid(x, y, "Ice", {
                Temperature = 0
            })
            return
        end
        if GetIfExists(x, y - 1) and (HasTag(x, y - 1, "Airlike") or (HasTag(x, y - 1, "Water_Replacable") and getRand(1,10) == 1)) then
            MoveFromGrid(x, y, x, y - 1)
        elseif GetIfExists(x, y - 1) and HasTag(x, y - 1, "Gas") then
            SwapFromGrid(x, y, x, y - 1)
        elseif GetIfExists(x + 1, y) and (HasTag(x+1, y, "Airlike") or HasTag(x+1, y, "Water_Replacable")) then
            MoveFromGrid(x, y, x + 1, y)
        elseif GetIfExists(x - 1, y) and (HasTag(x-1, y, "Airlike") or HasTag(x-1, y, "Water_Replacable")) then
            MoveFromGrid(x, y, x - 1, y)
        elseif GetIfExists(x, y - 1) and GetMaterial(x, y - 1) == "Water" and grid[x][y - 1]["Attributes"]["Temperature"] > grid[x][y]["Attributes"]["Temperature"] then
            SwapFromGrid(x, y, x, y - 1)
        end
    end,
    Oil = function(x, y)
        if not grid[x][y]["Attributes"]["heated"] then
            if getRand(1, 100) == 1 then
                for x1 = - 1, 1, 1 do
                    for y1 = - 1, 1, 1 do
                        if GetIfExists(x + x1, y + y1) and GetMaterial(x + x1, y + y1) == "Flame" then
                            grid[x][y]["Attributes"]["heated"] = true
                            break
                        end
                    end
                end
            end
        else
            grid[x][y]["Attributes"]["Lifetime"] = grid[x][y]["Attributes"]["Lifetime"] - 1
            for x1 = - 1, 1, 1 do
                for y1 = - 1, 1, 1 do
                    if GetIfExists(x + x1, y + y1) and GetMaterial(x + x1, y + y1) == "Air" then
                        SetGrid(x + x1, y + y1, "Flame", {})
                    end
                end
            end
            if grid[x][y]["Attributes"]["Lifetime"] <= 0 then
                for x1 = - 2, 2, 1 do
                    for y1 = - 2, 2, 1 do
                        if GetIfExists(x + x1, y + y1) and HasTag(x + x1, y + y1, "Heatable") then
                            grid[x + x1][y + y1]["Attributes"]["heated"] = true
                        end
                    end
                end
                SetGrid(x, y, "Air", {})
                return
            end
        end
        if GetIfExists(x, y - 1) and HasTag(x, y - 1, "Airlike") then
            MoveFromGrid(x, y, x, y - 1)
        elseif GetIfExists(x, y - 1) and (HasTag(x, y - 1, "Gas") or GetMaterial(x, y - 1) == "Water") then
            SwapFromGrid(x, y, x, y - 1)
        elseif GetIfExists(x + 1, y) and HasTag(x + 1, y, "Airlike") then
            MoveFromGrid(x, y, x + 1, y)
        elseif GetIfExists(x - 1, y) and HasTag(x - 1, y, "Airlike") then
            MoveFromGrid(x, y, x - 1, y)
        end
    end,
    Diesel = function(x, y)
        if not grid[x][y]["Attributes"]["heated"] then
            if getRand(1, 100) == 1 then
                for x1 = - 1, 1, 1 do
                    for y1 = - 1, 1, 1 do
                        if GetIfExists(x + x1, y + y1) and GetMaterial(x + x1, y + y1) == "Flame" then
                            grid[x][y]["Attributes"]["heated"] = true
                            break
                        end
                    end
                end
            end
        else
            grid[x][y]["Attributes"]["Lifetime"] = grid[x][y]["Attributes"]["Lifetime"] - 1
            for x1 = - 1, 1, 1 do
                for y1 = - 1, 1, 1 do
                    if GetIfExists(x + x1, y + y1) and GetMaterial(x + x1, y + y1) == "Air" then
                        SetGrid(x + x1, y + y1, "Flame", {
                            Lifetime = 20
                        })
                    end
                end
            end
            if grid[x][y]["Attributes"]["Lifetime"] <= 0 then
                for x1 = - 2, 2, 1 do
                    for y1 = - 2, 2, 1 do
                        if GetIfExists(x + x1, y + y1) and HasTag(x + x1, y + y1, "Heatable") then
                            grid[x + x1][y + y1]["Attributes"]["heated"] = true
                        end
                    end
                end
                SetGrid(x, y, "Air", {})
                return
            end
        end
        if GetIfExists(x, y - 1) and HasTag(x, y - 1, "Airlike") then
            MoveFromGrid(x, y, x, y - 1)
        elseif GetIfExists(x, y - 1) and (HasTag(x, y - 1, "Gas") or GetMaterial(x, y - 1) == "Water") then
            SwapFromGrid(x, y, x, y - 1)
        elseif GetIfExists(x + 1, y) and HasTag(x + 1, y, "Airlike") then
            MoveFromGrid(x, y, x + 1, y)
        elseif GetIfExists(x - 1, y) and HasTag(x - 1, y, "Airlike") then
            MoveFromGrid(x, y, x - 1, y)
        end
    end,
    Flame = function(x, y)
        for x1 = - 2, 2, 1 do
            for y1 = - 2, 2, 1 do
                if GetIfExists(x + x1, y + y1) and grid[x + x1][y + y1]["Attributes"]["Temperature"] then
                    grid[x + x1][y + y1]["Attributes"]["Temperature"] = grid[x + x1][y + y1]["Attributes"]["Temperature"] + Settings.FlameStrength
                end
                if GetIfExists(x + x1, y + y1) and HasTag(x + x1, y + y1, "Flame_Stopper") then
                    SetGrid(x, y, "Air", {})
                    return
                end
            end
        end
        if grid[x][y]["Attributes"]["Lifetime"] == 0 then
            SetGrid(x, y, "Air", {})
            return
        end
        if not (grid[x][y]["Attributes"]["Slowed"] and getRand(1, grid[x][y]["Attributes"]["Slowed"]) ~= 1) then
            grid[x][y]["Attributes"]["Lifetime"] = grid[x][y]["Attributes"]["Lifetime"] - 1
            if GetIfExists(x - 1, y + 1) and GetMaterial(x - 1, y + 1) == "Air" and getRand(1, 2) == 2 then
                MoveFromGrid(x, y, x - 1, y + 1)
            elseif GetIfExists(x + 1, y + 1) and GetMaterial(x + 1, y + 1) == "Air" and getRand(1, 2) == 2 then
                MoveFromGrid(x, y, x + 1, y + 1)
            elseif GetIfExists(x, y + 1) and GetMaterial(x, y + 1) == "Air" then
                MoveFromGrid(x, y, x, y + 1)
            end
        end
    end,
    Bomb = function(x, y)
        if grid[x][y]["Attributes"]["heated"] then
            for x1 = - 10, 10, 1 do
                for y1 = - 10, 10, 1 do
                    if GetIfExists(x + x1, y + y1) then
                        local delete = true
                        if GetMaterial(x + x1, y + y1) == "Bomb" and getRand(1, 5) ~= 1 then
                            delete = false
                        end
                        if not delete then
                            grid[x + x1][y + y1]["Attributes"]["heated"] = true
                        else
                            SetGrid(x + x1, y + y1, "Flame", {
                                Lifetime = 10,
                                Slowed = 20
                            })
                        end
                    end
                end
            end
        end
    end,
    Frost = function(x, y)
        for x1 = - 2, 2, 1 do
            for y1 = - 2, 2, 1 do
                if GetIfExists(x + x1, y + y1) and grid[x + x1][y + y1]["Attributes"]["Temperature"] then
                    grid[x + x1][y + y1]["Attributes"]["Temperature"] = grid[x + x1][y + y1]["Attributes"]["Temperature"] - Settings.FlameStrength
                end
            end
        end
        if grid[x][y]["Attributes"]["Lifetime"] == 60 then
            local distance = getRand(- 3, 3)
            if GetIfExists(x + distance, y) and GetMaterial(x + distance, y) == "Air" then
                MoveFromGrid(x, y, x + distance, y)
                return
            end
        end
        if grid[x][y]["Attributes"]["Lifetime"] == 0 then
            SetGrid(x, y, "Air", {})
            return
        end
        grid[x][y]["Attributes"]["Lifetime"] = grid[x][y]["Attributes"]["Lifetime"] - 1
        if GetIfExists(x, y - 1) and GetMaterial(x, y - 1) == "Air" then
            if getRand(1, 2) == 1 then
                MoveFromGrid(x, y, x, y - 1)
            end
        elseif GetIfExists(x + 1, y) and GetMaterial(x + 1, y) == "Air" then
            MoveFromGrid(x, y, x + 1, y)
        elseif GetIfExists(x - 1, y) and GetMaterial(x - 1, y) == "Air" then
            MoveFromGrid(x, y, x - 1, y)
        end
    end,
    Metal = function(x, y)
        if grid[x][y]["Attributes"]["Temperature"] > 900 then
            grid[x][y]["Tags"][3] = "Liquid"
            if GetIfExists(x, y - 1) and HasTag(x, y - 1, "Airlike") then
                MoveFromGrid(x, y, x, y - 1)
            elseif GetIfExists(x, y - 1) and HasTag(x, y - 1, "Powder") then
                SwapFromGrid(x, y, x, y - 1)
            elseif GetIfExists(x + 1, y) and HasTag(x + 1, y, "Airlike") then
                MoveFromGrid(x, y, x + 1, y)
            elseif GetIfExists(x - 1, y) and HasTag(x - 1, y, "Airlike") then
                MoveFromGrid(x, y, x - 1, y)
            end
        else
            grid[x][y]["Tags"][3] = nil
        end
    end,
    Stone = function(x, y)
        return
    end,
    Ceramic = function(x, y)
        return
    end,
    Glass = function(x, y)
        return
    end,
    Clay = function(x, y)
        if grid[x][y]["Attributes"]["Temperature"] > 500 then
            SetGrid(x, y, "Ceramic", {})
        end
    end,
    Extinguisher = function(x, y)
        return
    end,
    Torch = function(x, y)
        if not FindInTable(grid[x][y]["Tags"], "Lit") then
            return
        end
        if getRand(1, 20) == 1 then
            for x1 = - 1, 1, 1 do
                for y1 = - 1, 1, 1 do
                    if GetIfExists(x + x1, y + y1) and GetMaterial(x + x1, y + y1) == "Water" then
                        grid[x][y]["Tags"][2] = nil
                    end
                end
            end
        end
        if GetIfExists(x, y + 1) and GetMaterial(x, y + 1) == "Air" and getRand(1, 10) == 1 then
            SetGrid(x, y + 1, "Flame", {})
        end
    end,
    Well = function(x, y)
        if GetIfExists(x, y - 1) and GetMaterial(x, y - 1) == "Air" and getRand(1, 30) == 1 then
            SetGrid(x, y - 1, "Water", {})
        end
    end,
    Oil_Rig = function(x, y)
        if GetIfExists(x, y - 1) and GetMaterial(x, y - 1) == "Air" and getRand(1, 300) == 1 then
            SetGrid(x, y - 1, "Oil", {})
        end
    end,
    Vent = function(x, y)
        if not FindInTable(grid[x][y]["Tags"], "Active") then
            return
        end
        if getRand(1, 20) == 1 then
            for x1 = - 1, 1, 1 do
                for y1 = - 1, 1, 1 do
                    if GetIfExists(x + x1, y + y1) and GetMaterial(x + x1, y + y1) == "Metal" and grid[x + x1][y + y1]["Attributes"]["Temperature"] > 300 then
                        grid[x][y]["Tags"][2] = nil
                    end
                end
            end
        end
        if GetIfExists(x, y - 1) and GetMaterial(x, y - 1) == "Air" and getRand(1, 10) == 1 then
            SetGrid(x, y - 1, "Frost", {})
        end
    end,
    Steam = function(x, y)
        if grid[x][y]["Attributes"]["Temperature"] > 100 and (GetIfExists(x, y + 1) and HasTag(x, y + 1, "Solid")) or not GetIfExists(x, y + 1) then
            SetGrid(x, y, "Water", {
                Temperature = grid[x][y]["Attributes"]["Temperature"]
            })
            return
        end
        if getRand(1, 5) == 1 then
            if GetIfExists(x, y + 1) and HasTag(x, y + 1, "Airlike") then
                MoveFromGrid(x, y, x, y + 1)
            elseif GetIfExists(x, y + 1) and (HasTag(x, y + 1, "Liquid") or HasTag(x, y + 1, "Powder")) then
                SwapFromGrid(x, y, x, y + 1)
            elseif GetIfExists(x + 1, y) and HasTag(x + 1, y, "Airlike") then
                MoveFromGrid(x, y, x + 1, y)
            elseif GetIfExists(x - 1, y) and HasTag(x - 1, y, "Airlike") then
                MoveFromGrid(x, y, x - 1, y)
            end
        end
    end,
    Air = function(x, y)
        return
    end,
    Ice = function(x, y)
        if grid[x][y]["Attributes"]["Temperature"] > 0 then
            SetGrid(x, y, "Water", {
                Temperature = 0
            })
            return
        end
        if GetIfExists(x, y - 1) and HasTag(x, y - 1, "Airlike") then
            MoveFromGrid(x, y, x, y - 1)
        end
    end,
    Wood = function(x, y)
        if not grid[x][y]["Attributes"]["heated"] then
            if getRand(1, 100) == 1 then
                for x1 = - 1, 1, 1 do
                    for y1 = - 1, 1, 1 do
                        if GetIfExists(x + x1, y + y1) and GetMaterial(x + x1, y + y1) == "Flame" then
                            grid[x][y]["Attributes"]["heated"] = true
                            break
                        end
                    end
                end
            end
            if getRand(1, 1000) <= 2 then
                for x1 = - 1, 1, 1 do
                    for y1 = - 1, 1, 1 do
                        if GetIfExists(x + x1, y + y1) and GetMaterial(x + x1, y + y1) == "Seed" then
                            SetGrid(x, y, "Seed", {})
                            return
                        end
                    end
                end
            end
        else
            grid[x][y]["Attributes"]["Lifetime"] = grid[x][y]["Attributes"]["Lifetime"] - 1
            for x1 = - 1, 1, 1 do
                for y1 = - 1, 1, 1 do
                    if GetIfExists(x + x1, y + y1) and GetMaterial(x + x1, y + y1) == "Air" and getRand(1, 10) == 1 then
                        SetGrid(x + x1, y + y1, "Flame", {
                            Lifetime = 10
                        })
                    end
                end
            end
            if grid[x][y]["Attributes"]["Lifetime"] <= 0 then
                for x1 = - 2, 2, 1 do
                    for y1 = - 2, 2, 1 do
                        if GetIfExists(x + x1, y + y1) and HasTag(x + x1, y + y1, "Heatable") then
                            grid[x + x1][y + y1]["Attributes"]["heated"] = true
                        end
                    end
                end
                SetGrid(x, y, "Air", {})
                return
            end
        end
        if GetIfExists(x, y - 1) and HasTag(x, y - 1, "Airlike") then
            MoveFromGrid(x, y, x, y - 1)
        end
    end,
    Fuse = function(x, y)
        if not grid[x][y]["Attributes"]["heated"] then
            if getRand(1, 30) == 1 then
                for x1 = - 1, 1, 1 do
                    for y1 = - 1, 1, 1 do
                        if GetIfExists(x + x1, y + y1) and GetMaterial(x + x1, y + y1) == "Flame" then
                            grid[x][y]["Attributes"]["heated"] = true
                            break
                        end
                    end
                end
            end
        else
            grid[x][y]["Attributes"]["Lifetime"] = grid[x][y]["Attributes"]["Lifetime"] - 1
            for x1 = - 1, 1, 1 do
                for y1 = - 1, 1, 1 do
                    if GetIfExists(x+x1,y+y1) and GetMaterial(x+x1,y+y1) == "Air" then
                    SetGrid(x + x1, y + y1, "Flame", {
                        Lifetime = 4,
                        Slowed = 25
                    })
                end
                end
            end
            if grid[x][y]["Attributes"]["Lifetime"] <= 0 then
                for x1 = - 2, 2, 1 do
                    for y1 = - 2, 2, 1 do
                        if GetIfExists(x + x1, y + y1) and HasTag(x + x1, y + y1, "Heatable") then
                            grid[x + x1][y + y1]["Attributes"]["heated"] = true
                        end
                    end
                end
                SetGrid(x, y, "Air", {})
                return
            end
        end
    end,
    Paper = function(x, y)
        if not grid[x][y]["Attributes"]["heated"] then
            if getRand(1, 30) == 1 then
                for x1 = - 1, 1, 1 do
                    for y1 = - 1, 1, 1 do
                        if GetIfExists(x + x1, y + y1) and GetMaterial(x + x1, y + y1) == "Flame" then
                            grid[x][y]["Attributes"]["heated"] = true
                            break
                        end
                    end
                end
            end
        else
            grid[x][y]["Attributes"]["Lifetime"] = grid[x][y]["Attributes"]["Lifetime"] - 1
            for x1 = - 1, 1, 1 do
                for y1 = 0, 1, 1 do
                    if GetIfExists(x+x1,y+y1) and GetMaterial(x+x1,y+y1) == "Air" then
                    SetGrid(x + x1, y + y1, "Flame", {
                        Lifetime = 5
                    })
                end
                end
            end
            if grid[x][y]["Attributes"]["Lifetime"] <= 0 then
                for x1 = - 2, 2, 1 do
                    for y1 = - 2, 2, 1 do
                        if GetIfExists(x + x1, y + y1) and HasTag(x + x1, y + y1, "Heatable") then
                            grid[x + x1][y + y1]["Attributes"]["heated"] = true
                        end
                    end
                end
                SetGrid(x, y, "Air", {})
                return
            end
        end
    end,
    RFan = function(x, y)
        for x1 = 1, x - 1, 1 do
            if GetIfExists(x1 - 3, y) and HasTag(x1 - 3, y, "Airlike") then
                if HasTag(x1, y, "Liquid") or HasTag(x1, y, "Gas") or HasTag(x1, y, "Powder") then
                    MoveFromGrid(x1, y, x1 - 3, y)
                end
            end
        end
    end,
    Refinery = function(x, y)
        if getRand(1, 500) == 1 then
            if GetIfExists(x, y + 1) and GetMaterial(x, y + 1) == "Oil" then
                SetGrid(x, y + 1, "Air", {})
                if GetIfExists(x, y - 1) and HasTag(x, y - 1, "Airlike") then
                    SetGrid(x, y - 1, "Diesel", {})
                end
            end
        end
    end,
    LFan = function(x, y)
        for x1 = x + 1, Settings.PixelsX, 1 do
            if GetIfExists(x1 + 3, y) and HasTag(x1 + 3, y, "Airlike") then
                if HasTag(x1, y, "Liquid") or HasTag(x1, y, "Gas") or HasTag(x1, y, "Powder") then
                    MoveFromGrid(x1, y, x1 + 3, y)
                end
            end
        end
    end,
    Seed = function(x, y)
        if FindInTable(grid[x][y]["Tags"], "Burnt") then
            grid[x][y]["Attributes"]["Lifetime"] = grid[x][y]["Attributes"]["Lifetime"] - 1
            if grid[x][y]["Attributes"]["Lifetime"] <= 0 then
                SetGrid(x, y, "Air", {})
            end
            return
        end
        if grid[x][y]["Attributes"]["Temperature"] > 50 then
            grid[x][y]["Attributes"]["Lifetime"] = 300
            grid[x][y]["Tags"][2] = "Burnt"
            return
        end
        if grid[x][y]["Attributes"]["Water"] > 5 then
            if GetIfExists(x, y + 1) and GetMaterial(x, y + 1) == "Seed" then
                grid[x][y + 1]["Attributes"]["Water"] = grid[x][y + 1]["Attributes"]["Water"] + 1
                grid[x][y]["Attributes"]["Water"] = grid[x][y]["Attributes"]["Water"] - 1
            elseif GetIfExists(x + 1, y) and GetMaterial(x + 1, y) == "Seed" and getRand(1, 30) == 1 then
                grid[x + 1][y]["Attributes"]["Water"] = grid[x + 1][y]["Attributes"]["Water"] + 1
                grid[x][y]["Attributes"]["Water"] = grid[x][y]["Attributes"]["Water"] - 1
            elseif GetIfExists(x - 1, y) and GetMaterial(x - 1, y) == "Seed" and getRand(1, 30) == 1 then
                grid[x - 1][y]["Attributes"]["Water"] = grid[x - 1][y]["Attributes"]["Water"] + 1
                grid[x][y]["Attributes"]["Water"] = grid[x][y]["Attributes"]["Water"] - 1
            elseif grid[x][y]["Attributes"]["Water"] > 10 and getRand(1, 3) == 1 then
                if GetIfExists(x, y + 1) and (GetMaterial(x, y + 1) == "Sand" or GetMaterial(x, y + 1) == "Air") and getRand(1, 10) == 1 then
                    SetGrid(x, y + 1, "Seed", {})
                    grid[x][y]["Attributes"]["Water"] = grid[x][y]["Attributes"]["Water"] - 10
                elseif GetIfExists(x + 1, y) and (GetMaterial(x + 1, y) == "Sand" or GetMaterial(x + 1, y) == "Air") and getRand(1, 10) == 1 then
                    if GetIfExists(x + 1, y - 1) and GetMaterial(x + 1, y - 1) == "Air" and getRand(1, 3) == 1 then
                        SetGrid(x + 1, y, "Wood", {})
                    else
                        SetGrid(x + 1, y, "Seed", {})
                    end
                    grid[x][y]["Attributes"]["Water"] = grid[x][y]["Attributes"]["Water"] - 10
                elseif GetIfExists(x - 1, y) and (GetMaterial(x - 1, y) == "Sand" or GetMaterial(x - 1, y) == "Air") and getRand(1, 10) == 1 then
                    if GetIfExists(x - 1, y - 1) and GetMaterial(x - 1, y - 1) == "Air" and getRand(1, 3) == 1 then
                        SetGrid(x - 1, y, "Wood", {})
                    else
                        SetGrid(x - 1, y, "Seed", {})
                    end
                    grid[x][y]["Attributes"]["Water"] = grid[x][y]["Attributes"]["Water"] - 10
                end
            end
        end
        if getRand(1, 30) == 1 then
            for x1 = - 1, 1, 1 do
                for y1 = - 1, 1, 1 do
                    if GetIfExists(x + x1, y + y1) and GetMaterial(x + x1, y + y1) == "Water" then
                        SetGrid(x + x1, y + y1, "Air", {})
                        grid[x][y]["Attributes"]["Water"] = grid[x][y]["Attributes"]["Water"] + 1
                        break
                    elseif GetIfExists(x + x1, y + y1) and (GetMaterial(x + x1, y + y1) == "Oil" or GetMaterial(x + x1, y + y1) == "Diesel") then
                        grid[x][y]["Attributes"]["Lifetime"] = 300
                        if GetMaterial(x + x1, y + y1) == "Oil" or (GetMaterial(x + x1, y + y1) == "Diesel" and getRand(1, 3) == 1) then
                            SetGrid(x + x1, y + y1, "Air", {})
                        end
                        grid[x][y]["Tags"][2] = "Burnt"
                        return
                    end
                end
            end
        end
    end
}
local AllowedToPlace = {
    "Sand",
    "Water",
    "Wood",
    "Paper",
    "Metal",
    "Stone",
    "Clay",
    "Seed",
    "Fuse",
    "Bomb",
    "Oil",
    "Refinery",
    "LFan",
    "RFan",
    "Well",
    "Oil_Rig",
    "Extinguisher",
    "Torch",
    "Vent",
    "Flame",
    "Frost"
}
local placing = 1
local GetNextIndex = function(arr, curr)
    curr = curr + 1
    if curr == # arr + 1 then
        curr = 1
    end
    return curr
end
local GetPreviousIndex = function(arr, curr)
    curr = curr - 1
    if curr == 0 then
        curr = # arr
    end
    return curr
end
function UpdateGrid()
    grid = {}
    for x = 1, Settings.PixelsX, 1 do
        grid[x] = {}
        for y = 1, Settings.PixelsY, 1 do
            grid[x][y] = createCopy(Materials["Air"])
        end
    end
end
local GameFont
local GameFont18
function love.load()
    GameFont = love.graphics.newFont("MonospaceFont/HomeVideo-Bold.otf", 24, "normal", love.graphics.getDPIScale())
    GameFont18 = love.graphics.newFont("MonospaceFont/HomeVideo-Bold.otf", 18, "normal", love.graphics.getDPIScale())
    love.window.setTitle("Powder simulatior!!! -- GIDS214")
    love.window.setMode(640, 460, {
        resizable = true, minwidth = 100, minheight = 100
    })
    love.window.maximize()
    UpdateGrid()
end
local Xlocked, Ylocked = false, false
local game = true
local btn = 1
local buttons
local functionsToRun = {}
buttons = {
    {
        "Pixels X",
        function(up)
            if up then
                Settings.PixelsX = Settings.PixelsX + 10
            else
                Settings.PixelsX = Settings.PixelsX - 10
            end
            Settings.PixelsX = Clamp(Settings.PixelsX, 10, Settings.PixelsX + 100)
        end,
        "PixelsX"
    },
    {
        "Pixels Y",
        function(up)
            if up then
                Settings.PixelsY = Settings.PixelsY + 10
            else
                Settings.PixelsY = Settings.PixelsY - 10
            end
            Settings.PixelsY = Clamp(Settings.PixelsY, 10, Settings.PixelsY + 100)
        end,
        "PixelsY"
    },
    {
        "Simulations per Second",
        function(up)
            if up then
                Settings.GameSpeed = Settings.GameSpeed + 1
            else
                Settings.GameSpeed = Settings.GameSpeed - 1
            end
            Settings.GameSpeed = Clamp(Settings.GameSpeed, 1, 5)
        end,
        "GameSpeed"
    },
    {
        "Light Transparency",
        function(up)
            if up then
                Settings.LightTransparency = Settings.LightTransparency + 0.01
            else
                Settings.LightTransparency = Settings.LightTransparency - 0.01
            end
            Settings.LightTransparency = Clamp(Settings.LightTransparency, 0, 1)
        end,
        "LightTransparency"
    },
    {
        "Flame Power",
        function(up)
            if up then
                Settings.FlameStrength = Settings.FlameStrength + 0.1
            else
                Settings.FlameStrength = Settings.FlameStrength - 0.1
            end
            Settings.FlameStrength = Clamp(Settings.FlameStrength, 0.1, 4)
        end,
        "FlameStrength"
    },
    {
        "Heat Vision",
        function(up)
            Settings.HeatVision = up
        end,
        "HeatVision"
    },
    {
        "Save ID",
        function(up)
            if up then
                Settings.SaveId = Settings.SaveId + 1
            else
                Settings.SaveId = Settings.SaveId - 1
            end
            Settings.SaveId = Clamp(Settings.SaveId, 1, 100)
        end,
        "SaveId"
    },
    {
        "Save Data",
        function()
            local FileID = Settings.SaveId
            local FileName = "PowderSimulator_" .. tostring(FileID) .. ".txt"
            local ToSave = json.encode({
                Settings,
                grid
            })
            love.filesystem.write(FileName, ToSave)
            buttons[8][1] = "Saved"
            table.insert(functionsToRun, {
                timer + 2,
                function()
                    buttons[8][1] = "Save Data"
                end
            })
        end
    },
    {
        "Load Data",
        function()
            local FileID = Settings.SaveId
            local FileName = "PowderSimulator_" .. tostring(FileID) .. ".txt"
            if not love.filesystem.getInfo(FileName) then
                buttons[9][1] = "Save not found"
                table.insert(functionsToRun, {
                    timer + 2,
                    function()
                        buttons[9][1] = "Load Data"
                    end
                })
                return
            end
            local Data = json.decode(love.filesystem.read(FileName))
            Settings = Data[1]
            UpdateGrid()
            grid = Data[2]
            buttons[9][1] = "Loaded"
            table.insert(functionsToRun, {
                timer + 2,
                function()
                    buttons[9][1] = "Load Data"
                end
            })
        end
    },
    {
        "Apply Pixel Changes",
        function(up)
            UpdateGrid()
        end
    }
}
function love.keypressed(key, _, isRepeat)
    Keys[key] = key
    if key == "f" and not isRepeat then
        game = not game
    end
    if game then
        if key == "y" and not isRepeat then
            Ylocked = false
            if Xlocked then
                Xlocked = false
            else
                Xlocked = mouseX
            end
        end
        if key == "x" and not isRepeat then
            Xlocked = false
            if Ylocked then
                Ylocked = false
            else
                Ylocked = mouseY
            end
        end
        if key == "a" and not isRepeat then
            placing = GetPreviousIndex(AllowedToPlace, placing)
        end
        if key == "d" and not isRepeat then
            placing = GetNextIndex(AllowedToPlace, placing)
        end
    end
end
function love.keyreleased(key, _)
    Keys[key] = nil
end
function love.mousepressed(_, _, mbtn)
    Keys["mb" .. mbtn] = "mb" .. mbtn
    if (mbtn == 1 or mbtn == 2) and not game then
        local mx, my = love.mouse.getX(), love.mouse.getY()
        for i = 1, # buttons, 1 do
            local text = buttons[i][1]
            if buttons[i][3] and (type(Settings[buttons[i][3]]) == "number" or type(Settings[buttons[i][3]]) == "string") then
                text = buttons[i][1] .. " = " .. Settings[buttons[i][3]]
            elseif buttons[i][3] and type(Settings[buttons[i][3]]) == "boolean" then
                if Settings[buttons[i][3]] then
                    text = buttons[i][1] .. " = true"
                else
                    text = buttons[i][1] .. " = false"
                end
            end
            local textWidth = GameFont:getWidth(text)
            local textHeight = 24
            if ((windowSize[1] - textWidth) / 2) <= mx and mx <= ((windowSize[1] - textWidth) / 2) + textWidth + 4 then
                if 2 + (i - 1) * (textHeight + 10) <= my and my <= 2 + (i - 1) * (textHeight + 10) + textHeight + 4 then
                    if btn == i then
                        if mbtn == 1 then
                            buttons[btn][2](true)
                        else
                            buttons[btn][2](false)
                        end
                    end
                    btn = i
                    return
                end
            end
        end
    end
end
function love.mousereleased(_, _, mbtn)
    Keys["mb" .. mbtn] = nil
end
local radius = 1
function love.wheelmoved(x, y)
    if game then
        if y > 0 then
            radius = radius + 1
        elseif y < 0 then
            radius = radius - 1
        end
    end
end
local CellWidth, CellHeight = windowSize[1] / Settings.PixelsX, windowSize[2] / Settings.PixelsY
local fps = 0
local next = 0
function love.update(dt)
    timer = timer + dt
    if timer > next then
        next = next + 0.25
        fps = math.floor(1 / dt)
    end
    for i, obj in pairs(functionsToRun) do
        if timer > obj[1] then
            obj[2]()
            table.remove(functionsToRun, i)
        end
    end
    windowSize = {
        love.graphics.getPixelWidth(),
        love.graphics.getPixelHeight()
    }
    CellWidth, CellHeight = windowSize[1] / Settings.PixelsX, windowSize[2] / Settings.PixelsY
    mouseX, mouseY = Clamp(math.floor((windowSize[1] - love.mouse.getX()) / CellWidth + .5), 1, Settings.PixelsX), Clamp(math.floor((windowSize[2] - love.mouse.getY()) / CellHeight + .5), 1, Settings.PixelsY)
    if game then
        Settings.PixelsX = # grid
        Settings.PixelsY = # grid[1]
        if Xlocked then
            mouseX = Xlocked
        end
        if Ylocked then
            mouseY = Ylocked
        end
        if radius <= 0 then
            radius = 1
        end
        for i = 1, Settings.GameSpeed, 1 do
            for x = 1, Settings.PixelsX, 1 do
                for y = 1, Settings.PixelsY, 1 do
                    if GetMaterial(x, y) ~= "Air" then
                        if grid[x][y]["Attributes"]["Temperature"] then
                            if grid[x][y]["Attributes"]["Temperature"] > 20.1 then
                                grid[x][y]["Attributes"]["Temperature"] = grid[x][y]["Attributes"]["Temperature"] - 0.03
                            elseif grid[x][y]["Attributes"]["Temperature"] < 19.9 then
                                grid[x][y]["Attributes"]["Temperature"] = grid[x][y]["Attributes"]["Temperature"] + 0.03
                            end
                            for x1 = - 2, 2, 1 do
                                for y1 = - 2, 2, 1 do
                                    if GetIfExists(x + x1, y + y1) and grid[x + x1][y + y1]["Attributes"]["Temperature"] then
                                        local lower = math.min(grid[x][y]["Attributes"]["HeatTransfer"], grid[x + x1][y + y1]["Attributes"]["HeatTransfer"])
                                        local diff = math.abs(grid[x][y]["Attributes"]["Temperature"] - grid[x + x1][y + y1]["Attributes"]["Temperature"]) * lower
                                        if grid[x][y]["Attributes"]["Temperature"] > grid[x + x1][y + y1]["Attributes"]["Temperature"] then
                                            grid[x][y]["Attributes"]["Temperature"] = grid[x][y]["Attributes"]["Temperature"] - diff
                                            grid[x + x1][y + y1]["Attributes"]["Temperature"] = grid[x + x1][y + y1]["Attributes"]["Temperature"] + diff
                                        else
                                            grid[x][y]["Attributes"]["Temperature"] = grid[x][y]["Attributes"]["Temperature"] + diff
                                            grid[x + x1][y + y1]["Attributes"]["Temperature"] = grid[x + x1][y + y1]["Attributes"]["Temperature"] - diff
                                        end
                                    end
                                end
                            end
                        end
                        Ruleset[GetMaterial(x, y)](x, y)
                    end
                end
            end
            for x = 1, Settings.PixelsX, 1 do
                for y = 1, Settings.PixelsX, 1 do
                    if GetIfExists(x, y) and GetMaterial(x, y) ~= "Air" and grid[x][y]["Attributes"]["Temperature"] and grid[x][y]["Attributes"]["Temperature"] > 10000 then
                        grid[x][y]["Attributes"]["Temperature"] = 10000
                    elseif GetIfExists(x, y) and GetMaterial(x, y) ~= "Air" and grid[x][y]["Attributes"]["Temperature"] and grid[x][y]["Attributes"]["Temperature"] < - 273.15 then
                        grid[x][y]["Attributes"]["Temperature"] = - 273.15
                    end
                end
            end
            if Keys["mb1"] and love.mouse.getY() > 20 then
                for x1 = - radius + 1, radius, 1 do
                    for y1 = - radius + 1, radius, 1 do
                        if GetIfExists(mouseX + x1, mouseY + y1) and GetMaterial(mouseX + x1, mouseY + y1) == "Air" then
                            SetGrid(mouseX + x1, mouseY + y1, AllowedToPlace[placing], {})
                        end
                    end
                end
            end
            if Keys["mb2"] and love.mouse.getY() > 20 then
                for x1 = - radius + 1, radius, 1 do
                    for y1 = - radius + 1, radius, 1 do
                        if GetIfExists(mouseX + x1, mouseY + y1) then
                            SetGrid(mouseX + x1, mouseY + y1, "Air", {})
                        end
                    end
                end
            end
        end
    end
end
local tim = 0
local topDayColor = {75, 0, 0}
local bottomDayColor = {115, 80, 60}
local topNightColor = {19, 0, 51}
local bottomNightColor = {0, 30, 153}
function love.draw()
    love.graphics.setFont(GameFont)
    love.graphics.setLineWidth(2) 
    love.graphics.setBlendMode("alpha")  
    love.graphics.setBlendMode("add", "alphamultiply")
    tim = math.sin(timer/15)
    for i=windowSize[2],1,-1 do
        local maths = i/windowSize[2]
        local day = {lerp(bottomDayColor[1],topDayColor[1],maths),lerp(bottomDayColor[2],topDayColor[2],maths),lerp(bottomDayColor[3],topDayColor[3],maths)}
        local night = {lerp(bottomNightColor[1],topNightColor[1],maths),lerp(bottomNightColor[2],topNightColor[2],maths),lerp(bottomNightColor[3],topNightColor[3],maths)}
        love.graphics.setColor(lerp(day[1],night[1],tim)/255,lerp(day[2],night[2],tim)/255,lerp(day[3],night[3],tim)/255,1)
        love.graphics.rectangle("fill",0,windowSize[2]-i,windowSize[1],1)
    end
    if game then
        local radiusX = radius * CellWidth
        local radiusY = radius * CellHeight
        love.graphics.setBlendMode("alpha")
        if not Settings.HeatVision then
            for x = 1, Settings.PixelsX, 1 do
                for y = 1, Settings.PixelsY, 1 do
                    if GetMaterial(x, y) ~= "Air" then
                        local r, g, b,a = RenderOptions[GetMaterial(x, y)]["ColorFunc"](x, y, grid[x][y]["Color"][1], grid[x][y]["Color"][2], grid[x][y]["Color"][3])
                        love.graphics.setColor(r / 255, g / 255, b / 255, a or 1)
                        love.graphics.rectangle("fill", windowSize[1] - CellWidth * x, windowSize[2] - CellHeight * y, CellWidth, CellHeight)
                    elseif GetIfExists(x - 1, y) and GetIfExists(x + 1, y) and GetMaterial(x - 1, y) == GetMaterial(x + 1, y) and (HasTag(x - 1, y, "Liquid") or HasTag(x - 1, y, "Gas")) then
                        local r, g, b,a = RenderOptions[GetMaterial(x - 1, y)]["ColorFunc"](x + 1, y, grid[x + 1][y]["Color"][1], grid[x + 1][y]["Color"][2], grid[x + 1][y]["Color"][3])
                        love.graphics.setColor(r / 255, g / 255, b / 255, a or 1)
                        love.graphics.rectangle("fill", windowSize[1] - CellWidth * x, windowSize[2] - CellHeight * y, CellWidth, CellHeight)
                    end
                end
            end
            love.graphics.setBlendMode("add", "alphamultiply")
            for x = 1, Settings.PixelsX, 1 do
                for y = 1, Settings.PixelsY, 1 do
                    if GetMaterial(x, y) ~= "Air" and grid[x][y]["Attributes"]["Light"] and grid[x][y]["Attributes"]["Light"] > 0 then
                        for i = 1, grid[x][y]["Attributes"]["Light"], 1 do
                            local r, g, b = RenderOptions[GetMaterial(x, y)]["ColorFunc"](x, y, grid[x][y]["Color"][1], grid[x][y]["Color"][2], grid[x][y]["Color"][3])
                            love.graphics.setColor(r / 255, g / 255, b / 255, Settings.LightTransparency)
                            love.graphics.rectangle("fill", windowSize[1] - (x + i / 2) * CellWidth, windowSize[2] - (y + i / 2) * CellHeight, (i + 1) * CellWidth, (i + 1) * CellHeight)
                        end
                    end
                end
            end
        else
            love.graphics.setBlendMode("add", "alphamultiply")
            for x = 1, Settings.PixelsX, 1 do
                for y = 1, Settings.PixelsY, 1 do
                    if GetMaterial(x, y) ~= "Air" and grid[x][y]["Attributes"]["Temperature"] then
                        local temp = grid[x][y]["Attributes"]["Temperature"]
                        local r, g, b
                        if temp <= 0 then
                            r = lerp(55, 165, Clamp(1 - temp / - 273.15, 0, 1))
                            g = lerp(0, 100, Clamp(1 - temp / - 273.15, 0, 1))
                            b = lerp(255, 55, Clamp(1 - temp / - 273.15, 0, 1))
                        else
                            r = lerp(165, 255, Clamp(temp / 10000, 0, 1))
                            g = lerp(100, 0, Clamp(temp / 10000, 0, 1))
                            b = lerp(55, 0, Clamp(temp / 10000, 0, 1))
                        end
                        love.graphics.setColor(r / 255, g / 255, b / 255, .9)
                        love.graphics.rectangle("fill", windowSize[1] - CellWidth * x - CellWidth, windowSize[2] - CellHeight * y - CellHeight, CellWidth * 2, CellHeight * 2)
                    end
                end
            end
        end
        love.graphics.setBlendMode("alpha")
        love.graphics.setColor(1, 1, 1, 1)
        local drawMouseX, drawMouseY = Clamp(math.floor(love.mouse.getX() / CellWidth + .5), 1, Settings.PixelsX * CellWidth), Clamp(math.floor((love.mouse.getY()) / CellHeight + .5), 1, Settings.PixelsY * CellHeight)
        if GetIfExists(mouseX, mouseY) and GetMaterial(mouseX, mouseY) ~= "Air" and grid[mouseX][mouseY]["Attributes"] then
            local index = 0
            for i, attr in pairs(grid[mouseX][mouseY]["Attributes"]) do
                if type(attr) == "boolean" then
                    if attr then
                        love.graphics.print(i .. " true", 0, 24 * index)
                    else
                        love.graphics.print(i .. " false", 0, 24 * index)
                    end
                elseif type(attr) == "number" then
                    love.graphics.print(i .. " " .. math.floor(attr * 100) / 100, 0, 24 * index)
                else
                    love.graphics.print(i .. " " .. attr, 0, 24 * index)
                end
                index = index + 1
            end
        end
        if Xlocked then
            drawMouseX = Settings.PixelsX - Xlocked
        end
        if Ylocked then
            drawMouseY = Settings.PixelsY - Ylocked
        end
        if Xlocked then
            love.graphics.setColor(0, 1, 0, 1)
            love.graphics.rectangle("fill", (drawMouseX - radius) * CellWidth + radiusY - 1, 0, 2, windowSize[2])
        end
        if Ylocked then
            love.graphics.setColor(1, 0, 0, 1)
            love.graphics.rectangle("fill", 0, (drawMouseY - radius) * CellHeight + radiusX - 1, windowSize[1], 2)
        end
        love.graphics.setColor(1, 1, 1, .5)
        love.graphics.rectangle("line", (drawMouseX - radius) * CellWidth, (drawMouseY - radius) * CellHeight, radiusX * 2, radiusY * 2)
        local color = Materials[AllowedToPlace[placing]]["Color"]
        local r, g, b = color[1] / 255, color[2] / 255, color[3] / 255
        local text = " " .. AllowedToPlace[placing] .. " "
        local textWidth = GameFont:getWidth(text)
        local textHeight = GameFont:getHeight(text)
        love.graphics.setColor(r, g, b, .5)
        love.graphics.rectangle("line", (windowSize[1] - textWidth) / 2, 2, textWidth + 4, textHeight + 4)
        love.graphics.setColor(r, g, b, .2)
        love.graphics.rectangle("fill", (windowSize[1] - textWidth) / 2 + 1, 3, textWidth + 2, textHeight + 2)
        love.graphics.setColor(r, g, b, .8)
        love.graphics.print(text, (windowSize[1] - textWidth) / 2 + 5, 3)
        love.graphics.setFont(GameFont18)
        color = Materials[AllowedToPlace[GetNextIndex(AllowedToPlace, placing)]]["Color"]
        r, g, b = color[1] / 255, color[2] / 255, color[3] / 255
        local textNext = " " .. AllowedToPlace[GetNextIndex(AllowedToPlace, placing)] .. " "
        local textNextWidth = GameFont18:getWidth(textNext)
        local textNextHeight = GameFont18:getHeight(textNext)
        love.graphics.setColor(r, g, b, .5)
        love.graphics.rectangle("line", (windowSize[1] - textNextWidth) / 2 + textWidth + 5, 6, textNextWidth + 4, textNextHeight + 4)
        love.graphics.setColor(r, g, b, .2)
        love.graphics.rectangle("fill", (windowSize[1] - textNextWidth) / 2 + 1 + textWidth + 5, 7, textNextWidth + 2, textNextHeight + 2)
        love.graphics.setColor(r, g, b, .8)
        love.graphics.print(textNext, (windowSize[1] - textNextWidth) / 2 + 3 + textWidth + 5, 7)
        color = Materials[AllowedToPlace[GetPreviousIndex(AllowedToPlace, placing)]]["Color"]
        r, g, b = color[1] / 255, color[2] / 255, color[3] / 255
        local textPrev = " " .. AllowedToPlace[GetPreviousIndex(AllowedToPlace, placing)] .. " "
        local textPrevWidth = GameFont18:getWidth(textPrev)
        local textPrevHeight = GameFont18:getHeight(textPrev)
        love.graphics.setColor(r, g, b, .5)
        love.graphics.rectangle("line", (windowSize[1] - textPrevWidth) / 2 - textWidth - 5, 6, textPrevWidth + 4, textPrevHeight + 4)
        love.graphics.setColor(r, g, b, .2)
        love.graphics.rectangle("fill", (windowSize[1] - textPrevWidth) / 2 + 1 - textWidth - 5, 7, textPrevWidth + 2, textPrevHeight + 2)
        love.graphics.setColor(r, g, b, .8)
        love.graphics.print(textPrev, (windowSize[1] - textPrevWidth) / 2 + 3 - textWidth - 5, 7)
        love.graphics.setFont(GameFont)
    else
        for i = 1, # buttons, 1 do
            local text = buttons[i][1]
            if buttons[i][3] and (type(Settings[buttons[i][3]]) == "number" or type(Settings[buttons[i][3]]) == "string") then
                text = buttons[i][1] .. " = " .. Settings[buttons[i][3]]
            elseif buttons[i][3] and type(Settings[buttons[i][3]]) == "boolean" then
                if Settings[buttons[i][3]] then
                    text = buttons[i][1] .. " = true"
                else
                    text = buttons[i][1] .. " = false"
                end
            end
            local textWidth = GameFont:getWidth(text)
            local textHeight = 24
            if i == btn then
                love.graphics.setColor(0, .7, 0, .8)
            else
                love.graphics.setColor(1, 1, 1, .8)
            end
            love.graphics.rectangle("line", (windowSize[1] - textWidth) / 2, 2 + (i - 1) * (textHeight + 10), textWidth + 4, textHeight + 4)
            if i == btn then
                love.graphics.setColor(0, .7, 0, .2)
            else
                love.graphics.setColor(1, 1, 1, .2)
            end
            love.graphics.rectangle("fill", (windowSize[1] - textWidth) / 2 + 2, 2 + (i - 1) * (textHeight + 10) + 2, textWidth, textHeight)
            love.graphics.setColor(1, 1, 1, 1)
            love.graphics.print(text, (windowSize[1] - textWidth) / 2 + 2, 2 + (i - 1) * (textHeight + 10) + 2)
        end
    end
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.scale(.5)
    love.graphics.print(fps, 0, 0)
    local ver = "V3.8.6"
    love.graphics.print(ver, windowSize[1] * 2 - GameFont:getWidth(ver), windowSize[2] * 2 - GameFont:getHeight(ver))
end