local GenLib = require("GenLib")

function love.keypressed(key)
    GenLib.Keypressed(key)
end
function love.keyreleased(key)
    GenLib.Keyreleased(key)
end
function love.mousepressed(_, _, btn)
    GenLib.Mousepressed(btn)
end
function love.mousereleased(_, _, btn)
    GenLib.Mousereleased(btn)
end
local bg = nil
local font = nil
local font12 = nil
local player = {
    position = GenLib.newVector(GenLib.ScreenX / 2, GenLib.ScreenY / 2),
    velocity = GenLib.newVector(0, 0),
    health = 5,
    points = 0,
    bullets = 5,
    reload = 1,
    bulletReload = 5,
    bulletReloadStart = 3,
    BulletsPerAttack = 1,
    BulletPierce = 1,
    BulletDamage = 1,
    PointMultiplier = 1
}
local AllowWindowMovement = false
local shopOptions = {}
local points = {}
local enemies = {}
local bullets = {}
local Data = nil
local next = 5
local GameTimer = 0
local GameTimerMultiplier = 0.1
local frame = 0
local inShop = false
local price = 5
local ExplodeIntoPoints = function(pos, amount)
    for i = 1, amount, 1 do
        table.insert(
            points,
            {
                position = pos,
                velocity = GenLib.rand(5, 10),
                direction = GenLib.rand(0, 360),
                offset = GenLib.rand(0, 20)
            }
        )
    end
end
local options = {
    {"Split Bullet", "shoot one more\nbullet each attack", "BulletsPerAttack"},
    {"AP Bullet", "bullets pierce an\nadditional enemy", "BulletPierce"},
    {"Heavier Bullet", "bullets deal\nan extra damage", "BulletDamage"},
    {"Armor Upgrade", "gain an\nextra side", "health"},
    {"Fast Reloading", "reload bullets\nquicker", "bulletReload"},
    {"Wealth", "gain a multiplier\nfor points", "PointMultiplier"}
}
local RegenerateShop = function()
    for i = 1, 3, 1 do
        local rand = GenLib.rand(1, #options)
        shopOptions[i] = {
            options[rand][1],
            options[rand][2],
            price + GenLib.rand(-math.floor(price / 3), math.floor(price / 3)),
            options[rand][3]
        }
    end
end
function love.load()
    bg = love.graphics.newImage("background.png")
    font = love.graphics.newFont("Font.otf", 18, "normal", love.graphics.getDPIScale())
    font12 = love.graphics.newFont("Font.otf", 14, "normal", love.graphics.getDPIScale())
    love.window.setTitle("Polyground!!")
    love.window.setMode(500, 500, {resizable = false, borderless = not AllowWindowMovement})
    RegenerateShop()
end
local EnemyID = 1
Data = {
    square = {
        render = function(selfData)
            local verts = GenLib.getVertices(selfData.position, 4, 10, GameTimer * 20 + selfData.rotation * 70)
            love.graphics.setColor(119/255, 186/255, 54/255, 1)
            love.graphics.polygon("line", verts)
        end,
        update = function(selfData, dt)
            selfData.position =
                GenLib.add(selfData.position, GenLib.multiply(GenLib.angle(selfData.direction), dt * 100))

            local targetAngle = GenLib.getAngle(selfData.position, player.position)
            local dtPrime = (1 - 1 / (dt + 1)) / 2

            selfData.direction = GenLib.lerpAngle(selfData.direction, targetAngle, dtPrime * 10)

            if GenLib.magnitude(selfData.position, player.position) < 20 then
                player.health = player.health - 1
                return false
            end
            if selfData.health <= 0 then
                ExplodeIntoPoints(selfData.position, GenLib.rand(2, 5))
                return false
            end
            return true
        end,
        create = function()
            local infos = GenLib.deepCopy(Data.square.data)
            infos.position = GenLib.newVector(GenLib.rand(0, GenLib.ScreenX), GenLib.rand(0, GenLib.ScreenY))
            if GenLib.rand(0, 1) == 0 then
                infos.position.x = GenLib.rand(0, 1) * GenLib.ScreenX
            else
                infos.position.y = GenLib.rand(0, 1) * GenLib.ScreenY
            end
            infos.direction = GenLib.getAngle(infos.position, player.position) + GenLib.rand(-20, 20)
            infos.rotation = GenLib.rand(0, 100)
            infos.id = EnemyID
            EnemyID = EnemyID + 1
            table.insert(
                enemies,
                {
                    type = "square",
                    data = infos
                }
            )
        end,
        data = {
            position = nil,
            direction = 0,
            health = 3,
            rotation = 0,
            id = 0
        }
    },
    pentagon = {
        render = function(selfData)
            local verts = GenLib.getVertices(selfData.position, 5, 9, GameTimer * 30 + selfData.rotation * 70)
            love.graphics.setColor(0/255, 161/255, 255/255, math.sin(GenLib.timer) ^ 4)
            love.graphics.polygon("line", verts)
        end,
        update = function(selfData, dt, timer)
            if selfData.next == 2 then
                selfData.next = timer + GenLib.rand(10, 40) / 10
            end
            selfData.position =
                GenLib.add(
                selfData.position,
                GenLib.multiply(
                    GenLib.lookAt(selfData.position, player.position),
                    dt * 100 * GenLib.clamp(selfData.velocity, 0.2, selfData.velocity)
                )
            )
            if timer > selfData.next then
                selfData.next = timer + 2
                selfData.velocity = 9
            end
            selfData.velocity = GenLib.lerp(selfData.velocity, 0, 0.05)
            if GenLib.magnitude(selfData.position, player.position) < 15 then
                player.health = player.health - 1
                return false
            end
            if selfData.health <= 0 then
                ExplodeIntoPoints(selfData.position, GenLib.rand(4, 7))
                return false
            end
            return true
        end,
        create = function()
            local infos = GenLib.deepCopy(Data.pentagon.data)
            infos.position = GenLib.newVector(GenLib.rand(0, GenLib.ScreenX), GenLib.rand(0, GenLib.ScreenY))
            if GenLib.rand(0, 1) == 0 then
                infos.position.x = GenLib.rand(0, 1) * GenLib.ScreenX
            else
                infos.position.y = GenLib.rand(0, 1) * GenLib.ScreenY
            end
            infos.rotation = GenLib.rand(0, 100)
            infos.id = EnemyID
            EnemyID = EnemyID + 1
            table.insert(
                enemies,
                {
                    type = "pentagon",
                    data = infos
                }
            )
        end,
        data = {
            position = nil,
            velocity = 0,
            next = 2,
            health = 2,
            rotation = 0,
            id = 0
        }
    },
    hexagon = {
        render = function(selfData)
            local verts = GenLib.getVertices(selfData.position, 6, 15, GameTimer * 40 + selfData.rotation * 70)
            love.graphics.setColor(211/255, 100/255, 255/255, 1)
            love.graphics.polygon("line", verts)
            if selfData.shooting then
                local pos = GenLib.add(selfData.position, GenLib.multiply(GenLib.angle(selfData.aimDirection), 1000))
                love.graphics.setColor(
                    1,
                    0.5 - math.sin(GenLib.timer * 7) / 3,
                    0.5 - math.sin(GenLib.timer * 7) / 3,
                    0.5
                )
                love.graphics.setLineWidth(25)
                love.graphics.line(selfData.position.x, selfData.position.y, pos.x, pos.y)
                love.graphics.setColor(1, 1, 1, 0.5)
                love.graphics.setLineWidth(17)
                love.graphics.line(selfData.position.x, selfData.position.y, pos.x, pos.y)
                love.graphics.setLineWidth(2)
            end
        end,
        update = function(selfData, dt, timer)
            if selfData.shooting then
                selfData.aimDirection =
                    GenLib.lerp(selfData.aimDirection, GenLib.getAngle(selfData.position, player.position), 0.005)
                if selfData.next < timer then
                    selfData.shooting = false
                    selfData.next = timer + 1
                    if
                        GenLib.distanceToAxis(
                            player.position,
                            {origin = selfData.position, direction = GenLib.angle(selfData.aimDirection)}
                        ) < 13
                     then
                        player.health = player.health - 1
                        player.velocity = GenLib.multiply(GenLib.unit(player.velocity), -10)
                    end
                end
            else
                if selfData.next < timer then
                    selfData.shooting = true
                    selfData.aimDirection =
                        GenLib.getAngle(selfData.position, player.position) +
                        (GenLib.rand(0, 1) * 2 - 1) * GenLib.rand(10, 20)
                    selfData.next = timer + 3
                end
            end
            if selfData.next == -1 then
                selfData.next = timer + GenLib.rand(5, 10)
            end
            selfData.position =
                GenLib.lerpVector(
                selfData.position,
                GenLib.newVector(
                    selfData.targetpos.x * GenLib.WindowX + GenLib.WindowPositionX,
                    selfData.targetpos.y * GenLib.WindowY + GenLib.WindowPositionY
                ),
                0.05
            )
            if GenLib.magnitude(selfData.position, player.position) < 15 then
                player.health = player.health - 1
                return false
            end
            if selfData.health <= 0 then
                ExplodeIntoPoints(selfData.position, GenLib.rand(10, 12))
                return false
            end
            return true
        end,
        create = function()
            local infos = GenLib.deepCopy(Data.hexagon.data)
            infos.targetpos = GenLib.newVector(GenLib.rand(0, 100) / 100, GenLib.rand(0, 100) / 100)
            if GenLib.rand(0, 1) == 0 then
                infos.targetpos.x = GenLib.rand(0, 1)
            else
                infos.targetpos.y = GenLib.rand(0, 1)
            end
            infos.position =
                GenLib.newVector(
                infos.targetpos.x * GenLib.WindowX + GenLib.WindowPositionX,
                infos.targetpos.y * GenLib.WindowY + GenLib.WindowPositionY
            )

            infos.rotation = GenLib.rand(0, 100)
            infos.id = EnemyID
            EnemyID = EnemyID + 1
            table.insert(
                enemies,
                {
                    type = "hexagon",
                    data = infos
                }
            )
        end,
        data = {
            targetpos = nil,
            position = nil,
            next = -1,
            shooting = false,
            aimDirection = 0,
            health = 1,
            rotation = 0,
            id = 0
        }
    },
    worm = {
        render = function(selfData)
            local verts = GenLib.getVertices(selfData.position, 4, 30, 0)
            love.graphics.setColor(255/255, 0/255, 113/255, 1)
            love.graphics.polygon("line", verts)
            for i = 1, 10, 1 do
                verts = GenLib.getVertices(selfData.older[i], 4, 30, 0)
                love.graphics.polygon("line", verts)
            end
        end,
        update = function(selfData, dt, timer)
            local noiseX = (((math.sin(timer / 1.25) + 1) / 4 + 0.85) ^ 6) / 6
            local noiseY = (((math.cos(timer / 1.25) + 1) / 4 + 0.85) ^ 6) / 6
            selfData.position =
                GenLib.lerpVector(
                selfData.position,
                GenLib.newVector(noiseX * GenLib.ScreenX, noiseY * GenLib.ScreenY),
                0.2
            )

            for i = 1, 10, 1 do
                local next = selfData.older[i - 1] or selfData.position
                selfData.older[i] = GenLib.lerpVector(selfData.older[i], next, 0.05)
                local toDestroy = {}
                for x, bllt in pairs(bullets) do
                    if GenLib.magnitude(selfData.older(i)) < 30 then
                        table.insert(toDestroy, x)
                    end
                end
            end
            return true
        end,
        create = function()
            local infos = GenLib.deepCopy(Data.worm.data)
            local noiseX = (((math.sin(GenLib.timer / 1.25) + 1) / 4 + 0.85) ^ 6) / 6
            local noiseY = (((math.cos(GenLib.timer / 1.25) + 1) / 4 + 0.85) ^ 6) / 6
            infos.position = GenLib.newVector(noiseX * GenLib.ScreenX, noiseY * GenLib.ScreenY)
            for i = 1, 10, 1 do
                infos.older[i] = GenLib.deepCopy(infos.position)
            end
            infos.id = EnemyID
            EnemyID = EnemyID + 1
            table.insert(
                enemies,
                {
                    type = "worm",
                    data = infos
                }
            )
        end,
        data = {
            direction = 0,
            position = GenLib.zero,
            older = {},
            next = -1,
            health = 50,
            rotation = 0,
            id = 0
        }
    }
}
table.insert(
    GenLib.KeybindHoldFunctions,
    {
        "w",
        function(dt)
            if inShop then
                return
            end
            local dtPrime = (1 - 1 / (dt + 1)) / 2
            player.velocity = GenLib.add(player.velocity, GenLib.newVector(0, -7 * dtPrime * GameTimerMultiplier))
        end
    }
)
table.insert(
    GenLib.KeybindHoldFunctions,
    {
        "s",
        function(dt)
            if inShop then
                return
            end
            local dtPrime = (1 - 1 / (dt + 1)) / 2
            player.velocity = GenLib.add(player.velocity, GenLib.newVector(0, 7 * dtPrime * GameTimerMultiplier))
        end
    }
)
table.insert(
    GenLib.KeybindHoldFunctions,
    {
        "d",
        function(dt)
            if inShop then
                return
            end
            local dtPrime = (1 - 1 / (dt + 1)) / 2
            player.velocity = GenLib.add(player.velocity, GenLib.newVector(7 * dtPrime * GameTimerMultiplier, 0))
        end
    }
)
table.insert(
    GenLib.KeybindHoldFunctions,
    {
        "a",
        function(dt)
            if inShop then
                return
            end
            local dtPrime = (1 - 1 / (dt + 1)) / 2
            player.velocity = GenLib.add(player.velocity, GenLib.newVector(-7 * dtPrime * GameTimerMultiplier, 0))
        end
    }
)
local shopHitboxes = {
    {25, 145},
    {200, 300},
    {360, 475}
}
table.insert(
    GenLib.MousePressFunctions,
    {
        "MB1",
        function(dt)
            local dist =
                1 -
                30 /
                    GenLib.magnitude(
                        GenLib.newVector(GenLib.MouseX, GenLib.MouseY),
                        GenLib.newVector(GenLib.WindowX, 0)
                    )
            if dist < 0.15 then
                love.event.quit()
            end
            if inShop then
                for i = 0, 2, 1 do
                    if
                        shopHitboxes[i + 1][1] < GenLib.MouseX and GenLib.MouseX < shopHitboxes[i + 1][2] and
                            225 < GenLib.MouseY and
                            GenLib.MouseY < 255
                     then
                        if shopOptions[i + 1][3] <= player.points then
                            player.points = player.points - shopOptions[i + 1][3]
                            player[shopOptions[i + 1][4]] = player[shopOptions[i + 1][4]] + 1
                            price = math.ceil(price * 1.1)
                            RegenerateShop()
                        end
                    end
                end
            end
            if player.bullets > 0 then
                player.bullets = player.bullets - 1
                player.reload = GameTimer + player.bulletReloadStart / player.bulletReload
                local startangle = -7.5 * player.BulletsPerAttack / 2
                for i = 1, player.BulletsPerAttack, 1 do
                    table.insert(
                        bullets,
                        {
                            pierce = player.BulletPierce,
                            IgnoredIDs = {},
                            position = GenLib.deepCopy(player.position),
                            direction = GenLib.getAngle(
                                player.position,
                                GenLib.add(
                                    GenLib.newVector(GenLib.MouseX, GenLib.MouseY),
                                    GenLib.newVector(GenLib.WindowPositionX, GenLib.WindowPositionY)
                                )
                            ) +
                                GenLib.rand(-3, 3) +
                                7.5 * i -
                                7.5 / 2 +
                                startangle
                        }
                    )
                end
            end
        end
    }
)
table.insert(
    GenLib.KeybindPressFunctions,
    {
        "tab",
        function()
            inShop = not inShop
        end
    }
)
local BackgroundTimer = 0
local betweenSpawns = 5
--Data.worm.create()
function love.update(dt)
    GenLib.update(dt)
    if not inShop then
        GameTimer = GameTimer + dt * GameTimerMultiplier
        BackgroundTimer = BackgroundTimer + dt * GameTimerMultiplier
        frame = frame + 1
        if 1 / GameTimerMultiplier <= frame then
            frame = 0
            if player.bullets == 5 then
                player.reload = GameTimer + player.bulletReloadStart / player.bulletReload
            end
            if GameTimer > player.reload then
                player.bullets = player.bullets + 1
                player.reload = GameTimer + player.bulletReloadStart / player.bulletReload
            end
            local dist =
                1 -
                30 /
                    GenLib.magnitude(
                        GenLib.newVector(GenLib.MouseX, GenLib.MouseY),
                        GenLib.newVector(GenLib.WindowX, 0)
                    )
            GameTimerMultiplier = GenLib.clamp(dist, 0.2, 1)
            local dtPrime = (1 - 1 / (dt + 1)) / 2
            player.position = GenLib.add(player.position, player.velocity)
            player.velocity = GenLib.lerpVector(player.velocity, GenLib.zero, dtPrime * 4)
            if player.position.x < GenLib.WindowPositionX then
                player.velocity.x = GenLib.lerp(player.velocity.x, 10, dtPrime * 3)
            end
            if player.position.x > GenLib.WindowPositionX + GenLib.WindowX then
                player.velocity.x = GenLib.lerp(player.velocity.x, -10, dtPrime * 3)
            end
            if player.position.y < GenLib.WindowPositionY then
                player.velocity.y = GenLib.lerp(player.velocity.y, 10, dtPrime * 3)
            end
            if player.position.y > GenLib.WindowPositionY + GenLib.WindowY then
                player.velocity.y = GenLib.lerp(player.velocity.y, -10, dtPrime * 3)
            end
            local EnemyIndexesToRemove = {}
            for i, obj in pairs(enemies) do
                local survived = Data[obj.type].update(obj.data, dt, GameTimer)
                if not survived then
                    table.insert(EnemyIndexesToRemove, i)
                end
            end
            for i, obj in pairs(EnemyIndexesToRemove) do
                table.remove(enemies, obj)
            end
            local bulletIndexesToRemove = {}
            for i, obj in pairs(bullets) do
                obj.position = GenLib.add(obj.position, GenLib.multiply(GenLib.angle(obj.direction), 3))
                local died = false
                if
                    obj.position.x < 0 or obj.position.x > GenLib.ScreenX or obj.position.y < 0 or
                        obj.position.y > GenLib.ScreenY
                 then
                    died = true
                end
                for i, enemy in pairs(enemies) do
                    if
                        not died and GenLib.magnitude(enemy.data.position, obj.position) < 10 and
                            not obj.IgnoredIDs[enemy.data.id]
                     then
                        obj.IgnoredIDs[enemy.data.id] = true
                        enemy.data.health = enemy.data.health - player.BulletDamage
                        obj.pierce = obj.pierce - 1
                        if obj.pierce == 0 then
                            died = true
                        end
                    end
                end
                local PointsToRemove = {}
                for x, point in pairs(points) do
                    if GenLib.magnitude(point.position, obj.position) < 30 then
                        player.points = player.points + 1 + player.PointMultiplier / 4
                        table.insert(PointsToRemove, x)
                    end
                end
                for i, index in pairs(PointsToRemove) do
                    table.remove(points, index)
                end
                if died then
                    table.insert(bulletIndexesToRemove, i)
                end
            end
            for i, obj in pairs(bulletIndexesToRemove) do
                table.remove(bullets, obj)
            end

            if GameTimer > next then
                next = next + betweenSpawns
                betweenSpawns = betweenSpawns * 0.99
                local rng = GenLib.rand(1, 99)
                if 0 < rng and rng < 60 then
                    Data.square.create()
                elseif 60 <= rng and rng <= 85 then
                    Data.pentagon.create()
                elseif 85 <= rng and rng < 100 then
                    Data.hexagon.create()
                end
            end
            for i, point in pairs(points) do
                point.position =
                    GenLib.add(point.position, GenLib.multiply(GenLib.angle(point.direction), point.velocity))
                point.velocity = GenLib.lerp(point.velocity, 0, 0.1)
            end
        end
    else
        BackgroundTimer = BackgroundTimer + dt * GameTimerMultiplier
    end
    if player.health <= 0 then
        love.event.quit()
    end
end
local background = {}
local x1, y1 = 30, 10
for x = 1, x1, 1 do
    background[x] = {}
    for y = 1, y1, 1 do
        background[x][y] = {
            GenLib.rand(3, 6),
            GenLib.rand(0, 1) * 2 - 1,
            GenLib.rand(1, 10) * 10,
            {GenLib.rand(150, 255), GenLib.rand(150, 255), GenLib.rand(150, 255)},
            GenLib.rand(7, 15),
            GenLib.rand(-10, 10)
        }
    end
end
local bgX = 0
local bgY = 0
function love.draw()
    love.graphics.setLineStyle("smooth")
    love.graphics.setLineWidth(2)
    love.graphics.setFont(font)
    if not AllowWindowMovement then
        local x = math.sin(GameTimer / 10) * GenLib.ScreenX / 4 + GenLib.ScreenX / 2 - GenLib.WindowX / 2
        local y =
            math.cos(GameTimer * 2 / 10 + math.pi / 2) * GenLib.ScreenY / 4 + GenLib.ScreenY / 2 - GenLib.WindowY / 2
        love.window.setPosition(x, y)
    end
    local dist =
        1 - 30 / GenLib.magnitude(GenLib.newVector(GenLib.MouseX, GenLib.MouseY), GenLib.newVector(GenLib.WindowX, 0))
    love.graphics.setColor(1, dist, dist, 1)
    love.graphics.rectangle("line", GenLib.WindowX - 25, 5, 20, 20)

    love.graphics.translate(-GenLib.WindowPositionX, -GenLib.WindowPositionY)
    bgX = -love.math.noise(BackgroundTimer / 10)
    bgY = -love.math.noise(BackgroundTimer / 15)
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.draw(
        bg,
        bgX * GenLib.ScreenX,
        bgY * GenLib.ScreenY,
        0,
        GenLib.ScreenX / 128 * 2,
        GenLib.ScreenY / 128 * 2
    )
    for x = 1, x1, 1 do
        for y = 1, y1, 1 do
            local dat = background[x][y]
            love.graphics.push()
            love.graphics.setColor(dat[4][1] / 255, dat[4][2] / 255, dat[4][3] / 255, 0.85)
            local pos =
                GenLib.newVector(
                GenLib.ScreenX / x1 * x + math.cos(BackgroundTimer * 1.23) * dat[6] * dat[2] + math.cos(dat[6] * 3) * 10,
                GenLib.ScreenY / y1 * y + math.sin(BackgroundTimer) * dat[6] * dat[2] + math.sin(dat[6] * 2) * 10
            )
            local size = dat[5] * (math.cos(BackgroundTimer / 5 * dat[2] + dat[1] * 2) + 1) / 4 + 2
            local amnt = dat[1]
            local rotation = dat[3] + dat[2] * BackgroundTimer * 300
            local vertices = GenLib.getVertices(pos, amnt, size, rotation)
            love.graphics.polygon("line", vertices)
            love.graphics.pop()
        end
    end
    love.graphics.push()
    local r = 0.75 + math.sin(BackgroundTimer) * 0.25
    local g = 0.75 + math.sin(BackgroundTimer + 30) * 0.25
    local b = 0.75 + math.sin(BackgroundTimer + 60) * 0.25
    love.graphics.translate(GenLib.WindowPositionX, GenLib.WindowPositionY)
    love.graphics.setColor(r, g, b, 1)
    GenLib.printCentered(font, math.floor(player.points), GenLib.newVector(GenLib.WindowX / 2, 14))
    love.graphics.circle(
        "fill",
        GenLib.WindowX / 2 + GenLib.textWidth(font, math.floor(player.points)) / 2 + 8,
        GenLib.textHeight(font, math.floor(player.points)) / 2 + 2,
        4,
        4
    )
    love.graphics.pop()
    if inShop then
        love.graphics.translate(GenLib.WindowPositionX, GenLib.WindowPositionY)
        for i = 0, 2, 1 do
            love.graphics.setFont(font)
            love.graphics.setColor(r, g, b, 1)
            love.graphics.rectangle(
                "line",
                GenLib.WindowX / 3 * i + 10,
                GenLib.WindowY / 3 * 1.25,
                GenLib.WindowX / 3 - 20,
                GenLib.WindowY / 4
            )
            love.graphics.setColor(r, g, b, 0.25)
            love.graphics.rectangle(
                "fill",
                GenLib.WindowX / 3 * i + 10,
                GenLib.WindowY / 3 * 1.25,
                GenLib.WindowX / 3 - 20,
                GenLib.WindowY / 4
            )
            love.graphics.setColor(r, g, b, 1)
            local width = GenLib.textWidth(font, shopOptions[i + 1][1])
            local height = GenLib.textHeight(font, shopOptions[i + 1][1])
            GenLib.printCentered(
                font,
                shopOptions[i + 1][1],
                GenLib.newVector(
                    GenLib.WindowX / 3 * i + 10 + (GenLib.WindowX / 3 - 20) / 2,
                    GenLib.WindowY / 3 * 1.1 + GenLib.WindowY / 9
                )
            )
            GenLib.printCentered(
                font,
                shopOptions[i + 1][3],
                GenLib.newVector(
                    GenLib.WindowX / 3 * i + 10 + (GenLib.WindowX / 3 - 20) / 2,
                    GenLib.WindowY / 3 * 2 + GenLib.WindowY / 9 -
                        (GenLib.textHeight(font, shopOptions[i + 1][3]) + 3) * 3
                )
            )
            love.graphics.circle(
                "fill",
                GenLib.WindowX / 3 * i + 10 + (GenLib.WindowX / 3 - 20) / 2 +
                    GenLib.textWidth(font, shopOptions[i + 1][3]),
                GenLib.WindowY / 3 * 2 + GenLib.WindowY / 9 + 2 -
                    (GenLib.textHeight(font, shopOptions[i + 1][3]) + 3) * 3,
                4,
                4
            )
            love.graphics.rectangle(
                "line",
                GenLib.WindowX / 3 * i + 10 + (GenLib.WindowX / 3 - 20) / 2 - width / 2 - 4,
                GenLib.WindowY / 3 * 1.1 + GenLib.WindowY / 9 - height / 2 - 2,
                width + 8,
                height + 4
            )
            love.graphics.setFont(font12)
            GenLib.printCentered(
                font12,
                shopOptions[i + 1][2],
                GenLib.newVector(
                    GenLib.WindowX / 3 * i + 10 + (GenLib.WindowX / 3 - 20) / 2,
                    GenLib.WindowY / 3 * 1.25 + GenLib.WindowY / 9
                )
            )
        end
        return
    end
    love.graphics.push()
    for i, point in pairs(points) do
        r = 0.75 + math.sin(GameTimer + point.offset) * 0.25
        g = 0.75 + math.sin(GameTimer + 30 + point.offset) * 0.25
        b = 0.75 + math.sin(GameTimer + 60 + point.offset) * 0.25
        love.graphics.setColor(r, g, b, 1)
        love.graphics.circle("fill", point.position.x - 4, point.position.y - 4, 4, 4)
    end
    love.graphics.pop()
    love.graphics.push()
    local verts = GenLib.getVertices(player.position, player.health + 2, 10, GameTimer * 70)
    r = 0.75 + math.sin(GameTimer * (7 - player.health)) * 0.25
    g = 0.75
    b = 0.75
    love.graphics.setColor(r, g, b, 1)
    love.graphics.polygon("line", verts)
    love.graphics.pop()
    for i, bllt in pairs(bullets) do
        love.graphics.push()
        local verts = GenLib.getVertices(bllt.position, 3, 5, bllt.direction + 60)
        love.graphics.setColor(232/255, 230/255, 110/255, 1)
        love.graphics.polygon("line", verts)

        love.graphics.pop()
    end
    for i, obj in pairs(enemies) do
        love.graphics.push()
        Data[obj.type].render(obj.data)
        love.graphics.pop()
    end
    for i = 1, player.bullets, 1 do
        love.graphics.push()
        local pos = GenLib.add(player.position, GenLib.multiply(GenLib.angle(i * 72 + GameTimer * 100), 20))
        local verts =
            GenLib.getVertices(
            pos,
            3,
            5,
            GenLib.getAngle(
                pos,
                GenLib.add(
                    GenLib.newVector(GenLib.MouseX, GenLib.MouseY),
                    GenLib.newVector(GenLib.WindowPositionX, GenLib.WindowPositionY)
                )
            ) + 60
        )
        love.graphics.setColor(232/255, 230/255, 110/255, 1)
        love.graphics.polygon("line", verts)

        love.graphics.pop()
    end
end
