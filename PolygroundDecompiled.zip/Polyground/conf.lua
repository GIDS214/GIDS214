function love.conf(window)
    window.console = false
end
