-- made by GIDS214
--[[

Implementation:

local GenLib = require("GenLib")
function love.keypressed(key)
    GenLib.Keypressed(key)
end
function love.keyreleased(key)
    GenLib.Keyreleased(key)
end
function love.mousepressed(_,_,btn)
    GenLib.Mousepressed(btn)
end
function love.mousereleased(_,_,btn)
    GenLib.Mousereleased(btn)
end


In function love.update() add this:
    GenLib.update(dt)
]]
local module = {}

-- Variables
module.timer = 0
module.mousePos = {x=0,y=0}
module.dt = 0
module.WindowX = 0
module.WindowY = 0
module.WindowPositionX = 0
module.WindowPositionY = 0
module.ScreenX,module.ScreenY = love.window.getDesktopDimensions()
module.MouseX,module.MouseY = 0,0
-- Input Handler
module.Keys = {}
module.MB = {}
module.KeybindPressFunctions = {}
module.KeybindHoldFunctions = {}
module.KeybindReleaseFunctions = {}
module.MousePressFunctions = {}
module.MouseHoldFunctions = {}
module.MouseReleaseFunctions = {}
function module.Keypressed(key)
    module.Keys[key] = key
    for i, func in pairs(module.KeybindPressFunctions) do
        if func[1] == key then
        func[2](key)
        end
    end
end
function module.Keyreleased(key)
    module.Keys[key] = nil
    for i, func in pairs(module.KeybindReleaseFunctions) do
        if func[1] == key then
        func[2](key)
        end
    end
end

function module.Mousepressed(btn)
    module.MB["MB" .. btn] = "MB" .. btn
    for i, func in pairs(module.MousePressFunctions) do
        if func[1] == "MB" .. btn then
        func[2]("MB" .. btn)
        end
    end
end
function module.Mousereleased(btn)
    module.MB["MB" .. btn] = nil
    for i, func in pairs(module.MouseReleaseFunctions) do
        if func[1] == "MB" .. btn then
        func[2]("MB" .. btn)
        end
    end
end

function module.update(dt)
    module.dt = dt
    module.timer = module.timer + dt
    module.mousePos = {x=love.mouse.getX(),y=love.mouse.getY()}
    module.WindowX,module.WindowY = love.graphics.getDimensions()
    module.ScreenX,module.ScreenY = love.window.getDesktopDimensions()
    module.MouseX,module.MouseY=love.mouse.getX(),love.mouse.getY()
    local t = nil
    module.WindowPositionX,module.WindowPositionY,t = love.window.getPosition()
    for i, arr in pairs(module.KeybindHoldFunctions) do
        local key = arr[1]
        if module.Keys[key] then
            arr[2](dt)
        end
    end
    for i, arr in pairs(module.MouseHoldFunctions) do
        local key = arr[1]
        if module.MB[key] then
            arr[2](dt)
        end
    end
end

-- Generic Functions
function module.GetIndexesOfText(text,pattern)
    local ret = {}
    local patternlen = string.len(pattern)
    local textlen = string.len(text)
    for i=1,textlen,1 do
        if string.sub(text,i,i+patternlen-1) == pattern then
            table.insert(ret, i)
        end
    end
    table.sort(ret)
    return ret
end
function module.SplitText(text,pattern)
    if pattern == "" then
        local ret = {}
        for i=1,string.len(text),1 do
            table.insert(ret,string.sub(text,i,i))
        end
        table.sort(ret)
        return ret
    end
    if not text or text == "" or not pattern then return {} end
    local ret = {}
    local indexes = module.GetIndexesOfText(text,pattern)
    table.insert(indexes,string.len(text)+1)
    local len = string.len(pattern)
    local start = 1
    for i,v in pairs(indexes) do
        table.insert(ret,string.sub(text,start,v-1))
        start = v+1
    end
    table.sort(ret)
    return ret
end
function module.sign(num)
    if num < 0 then return -1 end
    if num == 0 then return 0 end
    if num > 0 then return 1 end
    return 0
end
function module.rand(min, max)
    return love.math.random(max - min + 1) + min - 1
end
function module.lerp(a, b, alpha)
    return a * (1 - alpha) + b * alpha
end
function module.lerpAngle(a, b, alpha)
    local diff = (b - a + 180) % 360 - 180
    return a + diff * alpha
end
function module.clamp(a, min, max)
    return math.min(max, math.max(min, a))
end
function module.overflow(a, min, max)
    if a < min then
        return max - (min - a)
    end
    if a > max then
        return min + (a - max)
    end
    return a
end
module.deepCopy = function(arr)
    local newArr = {}
    for key, value in pairs(arr) do
        if type(value) == "table" then
            newArr[key] = module.deepCopy(value)
        else
            newArr[key] = value
        end
    end
    return newArr
end
-- Vector Constants
module.one = { x = 1, y = 1 }
module.zero = { x = 0, y = 0 }
-- VectorSpecific Math
function module.scaleToOffsetX(x)
    return love.graphics.getPixelWidth() * x
end
function module.scaleToOffsetY(y)
    return love.graphics.getPixelHeight() * y
end
function module.offsetToScaleX(x)
    return x / love.graphics.getPixelWidth()
end

function module.offsetToScaleY(y)
    return y / love.graphics.getPixelHeight()
end

function module.vectorScaleToOffset(vec)
    return { x = module.ScaleToOffsetX(vec.x), y = module.ScaleToOffsetY(vec.y) }
end
function module.vectorOffsetToScale(vec)
    return { x = module.OffsetToScaleX(vec.x), y = module.OffsetToScaleY(vec.y) }
end
function module.substract(vec1, vec2)
    return { x = vec1.x - vec2.x, y = vec1.y - vec2.y }
end
function module.add(vec1, vec2)
    return { x = vec1.x + vec2.x, y = vec1.y + vec2.y }
end
function module.divide(vec, num)
    if num == 0 then
        return { x = 0, y = 0 }
    end
    return { x = vec.x / num, y = vec.y / num }
end
function module.multiply(vec, num)
    return { x = vec.x * num, y = vec.y * num }
end
function module.magnitude(vec1, vec2)
    return math.sqrt((vec2.x - vec1.x) ^ 2 + (vec2.y - vec1.y) ^ 2)
end
function module.unit(vec)
    local dist = module.magnitude(module.zero, vec)
    return module.divide(vec, dist)
end
function module.abs(vec)
    return { x = math.abs(vec.x), y = math.abs(vec.y) }
end
function module.angle(angle)
    return { x = math.cos(math.rad(angle)), y = math.sin(math.rad(angle)) }
end
function module.getAngle(vec1, vec2)
    return math.deg(math.atan2(vec2.y - vec1.y, vec2.x - vec1.x))
end
function module.lookAt(vec1, vec2)
    local dir = module.substract(vec2, vec1)
    return module.unit(dir)
end
function module.lerpVector(vec1, vec2, alpha)
    return module.add(vec1, module.multiply(module.substract(vec2, vec1), alpha))
end
function module.dot(vec1, vec2)
    vec1 = module.unit(vec1)
    vec2 = module.unit(vec2)
    return (vec1.x * vec2.x) + (vec1.y * vec2.y)
end
function module.newVector(x1, y1)
    return { x = x1, y = y1 }
end
function module.distanceToAxis(point, axis)
    local dir = module.unit(axis.direction)
    local vx = point.x - axis.origin.x
    local vy = point.y - axis.origin.y
    local distance = math.abs(vx * dir.y - vy * dir.x)
    return distance
end
-- Generic Functions
function module.getVertices(Startpos,vertices,scale,rotation)
    local verts = {}
    for i=1,vertices,1 do
        local pos = module.multiply(module.angle(360/vertices*i+rotation+180/vertices),scale)
        table.insert(verts,pos.x+Startpos.x)
        table.insert(verts,pos.y+Startpos.y)
    end
    return verts
end

-- Text Functions
function module.textWidth(font,text)
    return font:getWidth(text)
end
function module.textHeight(font,text)
    return font:getHeight(text)
end
function module.printCentered(font,text,pos)
    local textWidth = module.textWidth(font,text)
    local textHeight = module.textHeight(font,text)
    pos = module.substract(pos,module.newVector(textWidth/2,textHeight/2))
    love.graphics.print(text,pos.x,pos.y)
end
function module.FormatText(text,font,maxX)
    local spaceIndexes = module.GetIndexesOfText(text,"")
    table.insert(spaceIndexes,string.len(text)+1)
    local last = spaceIndexes[1]
    local final = ""
    local ToAdd = ""
    for _,current in pairs(spaceIndexes) do
        current = current-1
        if module.textWidth(font,ToAdd.. string.sub(text,last,current)) >= maxX then
            final = final.. "\n".. ToAdd.. string.sub(text,last,current)
            ToAdd = ""
            last = current+2
        end
        ToAdd = ToAdd.. string.sub(text,last,current)
    end
    final = final.. ToAdd
    return final
end

-- Color Functions
function module.newColor(r,g,b,a)
    return {r=r/255,g=g/255,b=b/255,a=a or 1}
end
-- UI object Functions
function module.AdvancedDrawRect(pos,size,origin,color,outlined,screenBased)
    outlined = outlined or "fill"
    love.graphics.push()
    love.graphics.origin()
    love.graphics.setColor(color.r,color.g,color.b,color.a)
    local posX,posY = pos.x,pos.y

    if screenBased then
        posX = posX-module.WindowPositionX
        posY = posY-module.WindowPositionY
        posX = posX+origin.x*module.ScreenX
        posY = posY+origin.y*module.ScreenY
    else
        posX = posX+origin.x*module.WindowX
        posY = posY+origin.y*module.WindowY
    end
    posX = posX-size.x/2
    posY = posY-size.y/2
    love.graphics.rectangle(outlined,posX,posY,size.x,size.y)
    love.graphics.pop()
end
function module.AdvancedBackgroundPrint(font,text,pos,size,origin,BackgroundColor,textColor,outlined,screenBased)
    outlined = outlined or "fill"
    love.graphics.push()
    love.graphics.origin()
    local posX,posY = pos.x,pos.y

    if screenBased then
        posX = posX-module.WindowPositionX
        posY = posY-module.WindowPositionY
        posX = posX+origin.x*module.ScreenX
        posY = posY+origin.y*module.ScreenY
    else
        posX = posX+origin.x*module.WindowX
        posY = posY+origin.y*module.WindowY
    end
    posX = posX-size.x/2
    posY = posY-size.y/2
    text = module.FormatText(text,font,size.x)
    love.graphics.setColor(BackgroundColor.r,BackgroundColor.g,BackgroundColor.b,BackgroundColor.a)
    love.graphics.rectangle(outlined,posX,posY,size.x,size.y)
    love.graphics.setColor(textColor.r,textColor.g,textColor.b,textColor.a)
    love.graphics.print(text,posX,posY)
    love.graphics.pop()
end
function module.AdvancedPrint(font,text,pos,size,origin,textColor,screenBased)
    love.graphics.push()
    love.graphics.origin()
    local posX,posY = pos.x,pos.y

    if screenBased then
        posX = posX-module.WindowPositionX
        posY = posY-module.WindowPositionY
        posX = posX+origin.x*module.ScreenX
        posY = posY+origin.y*module.ScreenY
    else
        posX = posX+origin.x*module.WindowX
        posY = posY+origin.y*module.WindowY
    end
    posX = posX-size.x/2
    posY = posY-size.y/2
    text = module.FormatText(text,font,size.x)
    love.graphics.setColor(textColor.r,textColor.g,textColor.b,textColor.a)
    love.graphics.print(text,posX,posY)
    love.graphics.pop()
end
return module
--V1
